�
�
g
type.googleapis.com/MapNavI

29.6591.12布达拉宫�&A-6adcfa50-6d1c-424d-a7b3-4759f396471b&DA5444c23b-2354-4fd7-ad33-ca88b72cfcc6���1 �פ��12去布达拉宫:3用高德地图，一键导航到拉萨布达拉宫
�
e
type.googleapis.com/ShowToastD
请在5秒内打开抖音�&A-6b18e53c-a8ce-404b-ae29-4e4482ea8b89
�
type.googleapis.com/Delay��'�{延迟五秒，便于一键指令开始时，给用户时间，打开抖音，否则循环条件不满足就立即结束了�&A-183bb83e-ada6-4970-b005-37fb95bbbbbe
�
type.googleapis.com/WhileLoop�
k
"type.googleapis.com/CurrentPkgListE

com.ss.android.ugc.aweme�&C-018f9535-6a9d-4ead-ba16-f7f8c6a6975f�
type.googleapis.com/InputSwipe���� �
(d�n通过循环，每隔几秒时间执行滑动动作，通过下方的显示指针，可以快速找到xy坐标�&A-743b5438-3c43-4b55-9678-44fe3e7bf8f3(�0�N�-通过循环，每隔几秒执行滑动动作�&A-141bdadf-5fb9-425d-8909-546099f03a8b
�
type.googleapis.com/ShowDanmu�
抖音切换结束�E条件不满足了或者次数到达设定值，循环就会结束了�&A-282a47b8-8ab1-49d5-a155-6b9cc53f11b3&DA1cb97c60-1c0a-464b-9775-9c8dbd18b834���1 �����12抖音切换:*固定时间自动滑动切换抖音视频
�
t
!type.googleapis.com/SetAppEnabledO	毒瘤app�请修改此处应用集�&A-28d4da95-387b-4ce3-a8a0-6e22ecf3d0af&DA942b10a8-6832-454b-a5a9-481264c72e8e믓1 ��ྊ12一键冻结:一键冻结不常用的应用
�
�
$type.googleapis.com/PostNotificatione
test
恭喜🎉支付宝到账100元 2alipay-fill8@�&A-e1ad9d6c-2a2c-482b-9c7d-51678e1716ed&DAb4eeb498-39a4-49ce-92a0-1e87c3153bb7�˓1 �֚��12发出通知:显示一个通知栏消息
�
S
type.googleapis.com/StopApp4	毒瘤app�&A-655113d2-b3ed-4e27-ae57-e8caa979cd75&DAea017d89-bd4d-4106-bdfe-fc8eda873442�ד1 ���12一键清理后台:!一键停止应用集中的应用
�	

type.googleapis.com/NoAction_

weibo-fill�'你知道此处无动作的用处吗？�&A-f3672823-4223-4591-a41a-187a0de4c3e9
Z
type.googleapis.com/StopApp;

com.sina.weibo�&A-03834c5e-c660-4a53-839d-c8ed33f4f6e6
m
type.googleapis.com/DelayP��!停止后要等会防止打不开�&A-59c692d6-a9f3-4603-97ad-5a648c6e847a
�
*type.googleapis.com/StartActivityUrlSchemaV
sinaweibo://compose�这是发微博的url�&A-85b32f0f-1689-4ca8-aa5d-bf7975607fd1
n
*type.googleapis.com/FindAndClickViewByText@
跳过�跳过广告�&A-22e7666f-3a05-4bf9-9d68-8047712f3501
�
type.googleapis.com/InputTape���3触摸输入区域，后面就可以输入内容了�&A-59c93b98-1939-49cf-a6ee-a571dafcfc76
I
type.googleapis.com/Delay,��&A-53c84506-41a7-4a50-ac84-b653b224d117
�
type.googleapis.com/InputTextg
<这是一条测试内容，通过ShortX一键指令发布。�&A-fbe0e841-8440-427d-a958-7f59a205bf0e
_
*type.googleapis.com/FindAndClickViewByText1
发送�&A-cd68a7f0-d67d-4739-a3e6-ea47fbbd880d
^
type.googleapis.com/ShowDanmu=
微博发送完了�&A-40f392cb-b131-4588-a2d9-effc9835bbab&DA1735efcb-291f-4975-9110-60b47b75d44a����1 ��Ὴ12微博:一键发微博