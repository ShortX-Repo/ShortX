�
�
currentActivity�
type.googleapis.com/StringVar�
�intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10200000;component=tornaco.apps.shortx/.ui.main.MainActivity;sourceBounds=540%20477%20788%20767;end
type.googleapis.com/StringVar