ǀ
�

com.quark.browser

tornaco.apps.shortx

com.sankuai.meituan

com.qidian.QDReader

org.lsposed.manager

com.sidesand.millet

xyz.chenzyadb.cu_toolbox

github.tornaco.android.thanos

com.ss.android.ugc.aweme

com.ss.android.auto

com.topjohnwu.magisk

com.absinthe.anywhere_

com.zhihu.android

com.coolapk.market

com.jingdong.app.mall

com.autonavi.minimap

tv.danmaku.biliUser 
�<
/
-com.android.connectivity.resources.mz.overlay

com.android.cts.priv.ctsshim

com.meizu.ems

com.meizu.pps

com.flyme.aod

com.qualcomm.qti.qcolor

com.android.uwb.resources

com.meizu.net.pedometer
6
4com.android.internal.display.cutout.emulation.corner

com.android.adservices.api
6
4com.android.internal.display.cutout.emulation.double
!
com.android.providers.telephony

com.android.dynsystem
'
%com.android.wifi.resources.overlay.mz
 
com.android.providers.calendar

com.meizu.regservice

com.meizu.todolist

com.android.providers.media

com.qti.service.colorservice
'
%com.google.android.onetimeinitializer

com.google.android.ext.shared
9
7com.android.internal.systemui.navbar.gestural_wide_back
!
com.qualcomm.qti.server.qtiwifi

com.qualcomm.qti.simcontacts
5
3com.android.internal.systemui.navbar.gestural_mback

com.meizu.flyme.launcher

com.android.wallpapercropper
%
#com.android.networkstack.overlay.mz

youlinw.providers.Overlay

com.android.protips

com.activate.activatephone

com.meizu.account.pay

com.android.documentsui

com.android.externalstorage

com.android.alarmclock

com.qualcomm.uimremoteclient

com.android.htmlviewer
!
com.qualcomm.qti.uceShimService
$
"com.android.companiondevicemanager

com.meizu.powersave

com.android.mms.service
!
com.android.providers.downloads

com.meizu.filemanager
#
!vendor.qti.hardware.cacert.server

com.quicinc.voice.activation
#
!com.qualcomm.qti.telephonyservice
"
 com.qualcomm.qti.performancemode

com.android.browser

com.meizu.flyme.directservice
 
com.qualcomm.qti.ridemodeaudio

vendor.qti.iwlan
"
 com.google.android.configupdater

com.android.soundrecorder

com.qualcomm.uimremoteserver

android.qvaoverlay.common
$
"com.android.safetycenter.resources
$
"com.android.providers.downloads.ui

com.android.vending

com.android.pacprocessor

com.android.simappdialog

com.android.networkstack

android.overlay.common
$
"com.android.connectivity.resources
4
2com.android.internal.display.cutout.emulation.hole
4
2com.android.internal.display.cutout.emulation.tall

com.android.modulemetadata

com.android.certinstaller

com.android.carrierconfig

com.meizu.assistant

com.wapi.wapicertmanage
2
0com.android.internal.systemui.navbar.threebutton
)
'com.qti.qualcomm.datastatusnotification

com.android.wifi.dialog
	
android

com.qualcomm.wfd.service

com.meizu.feedback

android.miui.overlay

com.meizu.media.camera

com.qti.qualcomm.deviceinfo

com.rongcard.eid

com.meizu.mstore

com.android.egg

com.android.mms

com.android.mtp

com.android.nfc

com.android.ons

com.android.stk

com.meizu.net.search

com.android.backupconfirm

com.meizu.perfui

com.meizu.picker

com.meizu.sceneinfo

com.android.provision

org.codeaurora.ims

com.meizu.notepaper

com.meizu.flyme.calculator
-
+com.google.android.overlay.gmsconfig.common
#
!com.android.settings.intelligence

com.android.calendar
#
!com.meizu.activeviewlivewallpaper
?
=com.android.internal.systemui.navbar.gestural_extra_wide_back

com.meizu.safe
#
!com.miui.systemui.devices.overlay
$
"com.qualcomm.qti.dynamicddsservice

com.qualcomm.qti.xrvd.service

com.qualcomm.qcrilmsgtunnel

com.meizu.flyme.toolbox
 
com.meizu.connectivitysettings
 
com.android.providers.settings
!
com.android.sharedstoragebackup

com.android.printspooler
+
)com.android.wifi.resources.overlay.common

cn.wps.moffice.lite.meizu

com.meizu.wallpapersetting

org.ifaa.aidl.manager

com.android.dreams.basic

com.android.incallui

com.android.se

com.android.inputdevices

com.fido.asm

com.meizu.flyme.sdkstage

com.flyme.systemuiex

com.android.bips

com.qti.dpmserviceapp

com.meizu.gamecenter.service

com.ibimuyu.lockscreen

com.qti.xdivert

com.android.musicfx
%
#com.android.settings.overlay.common
#
!com.android.cellbroadcastreceiver

com.google.android.webview

com.android.server.telecom
"
 com.android.cellbroadcastservice

com.android.keychain

com.qti.snapdragon.qdcm_ff

com.android.dialer

com.flyme.systemuitools

com.google.android.gms

com.google.android.gsf

com.meizu.account

android.ext.services

com.android.wifi.resources
"
 com.android.phone.overlay.common
*
(com.android.carrierconfig.overlay.common

com.android.calllogbackup
!
com.google.android.partnersetup
%
#com.android.systemui.overlay.common

com.android.cameraextensions
+
)com.android.server.telecom.overlay.common

com.android.localtransport

com.meizu.facerecognition

com.android.packageinstaller
*
(com.google.android.overlay.gmsconfig.gsa

com.android.carrierdefaultapp
 
com.qualcomm.qti.powersavemode
$
"com.qualcomm.qti.remoteSimlockAuth

com.flyme.safebox
*
(com.qualcomm.qti.devicestatisticsservice
(
&com.android.theme.font.notoserifsource

com.meizu.media.gallery

com.android.proxyhandler
9
7com.android.internal.display.cutout.emulation.waterfall
%
#com.qualcomm.qti.workloadclassifier

com.android.nearby.halfsheet

com.flyme.scanner
0
.com.google.android.printservice.recommendation
*
(com.google.android.syncadapters.calendar

com.meizu.alphame
!
com.android.managedprovisioning
$
"com.android.networkstack.tethering

com.android.soundpicker

com.meizu.dataservice

com.tencent.soter.soterserver

com.flyme.netadmin

com.android.dreams.phototable
 
com.goodix.fingerprint.setting

com.upuphone.easyshare

com.meizu.remotecooperation
!
com.meizu.telephonyengineermode

com.android.smspush
"
 com.android.wallpaper.livepicker

com.meizu.flyme.find
*
(com.android.cellbroadcastreceiver.module

com.meizu.voiceassistant
#
!com.android.imsserviceentitlement

com.meizu.cloud

com.meizu.setup

com.meizu.share

com.meizu.media.imageservice

com.android.storagemanager

com.android.bookmarkprovider

com.android.settings

com.qualcomm.qti.cne

com.qualcomm.qti.ims

com.qualcomm.qti.lpa

com.qualcomm.qti.sva

com.qualcomm.qti.uim

com.meizu.battery

org.mipay.android.manager

com.meizu.mzsyncservice

com.meizu.privacy

com.meizu.datamigration

com.meizu.suggestion

com.meizu.location

com.android.cts.ctsshim

com.android.remoteprovisioner

com.flyme.alivewallpaper

com.qualcomm.qti.uimGbaApp
+
)com.miui.systemui.overlay.devices.android

com.android.vpndialogs

youlinw.settings.Overlay

com.meizu.meizuuwbtest

com.meizu.flyme.service.find

com.android.phone

com.meizu.mzbasestationsafe

com.android.shell

com.android.sdksandbox

com.android.wallpaperbackup
%
#com.android.providers.blockednumber
&
$com.android.providers.userdictionary
$
"com.android.providers.media.module

com.android.emergency

com.meizu.customizecenter

com.android.hotspot2.osulogin

com.qualcomm.qti.xrcb
/
-com.android.internal.systemui.navbar.gestural

com.android.location.fused

com.meizu.flyme.gamecenter

com.android.systemui

com.meizu.callsetting
"
 com.android.bluetoothmidiservice
 
com.qualcomm.qti.poweroffalarm

com.meizu.netcontactservice

com.qti.phone
"
 com.android.permissioncontroller

com.android.traceur

com.flyme.auto.launcherflow

com.qti.dcf

com.qti.qcc

com.qualcomm.qtil.aptxui
.
,com.android.ondevicepersonalization.services

com.qualcomm.qtil.btdsda

com.android.bluetooth
"
 com.sohu.inputmethod.sogou.meizu

com.qualcomm.timeservice

com.qualcomm.atfwd

com.qualcomm.embms
 
com.android.providers.contacts

vendor.qti.imsrcs
 
com.android.captiveportallogin
;
9com.android.internal.systemui.navbar.gestural_narrow_back

com.meizu.flyme.weather
2
0com.android.cellbroadcastreceiver.overlay.common
%
#com.flyme.telecom.usagedata.service
 
com.meizu.net.nativelockscreenSystem 
_

tornaco.apps.shortx

com.sidesand.millet

github.tornaco.android.thanosXposedModule 
�?
/
-com.android.connectivity.resources.mz.overlay

com.android.cts.priv.ctsshim

com.meizu.ems

com.meizu.pps

com.quark.browser

com.flyme.aod

com.qualcomm.qti.qcolor

com.android.uwb.resources

com.meizu.net.pedometer
6
4com.android.internal.display.cutout.emulation.corner

com.android.adservices.api
6
4com.android.internal.display.cutout.emulation.double
!
com.android.providers.telephony

com.android.dynsystem
'
%com.android.wifi.resources.overlay.mz
 
com.android.providers.calendar

com.meizu.regservice

com.meizu.todolist

com.android.providers.media

com.qti.service.colorservice
'
%com.google.android.onetimeinitializer

com.google.android.ext.shared
9
7com.android.internal.systemui.navbar.gestural_wide_back
!
com.qualcomm.qti.server.qtiwifi

com.qualcomm.qti.simcontacts
5
3com.android.internal.systemui.navbar.gestural_mback

com.meizu.flyme.launcher

com.android.wallpapercropper

tornaco.apps.shortx
%
#com.android.networkstack.overlay.mz

com.sankuai.meituan

youlinw.providers.Overlay

com.android.protips

com.activate.activatephone

com.meizu.account.pay

com.android.documentsui

com.android.externalstorage

com.android.alarmclock

com.qualcomm.uimremoteclient

com.android.htmlviewer
!
com.qualcomm.qti.uceShimService
$
"com.android.companiondevicemanager

com.meizu.powersave

com.android.mms.service
!
com.android.providers.downloads

com.meizu.filemanager
#
!vendor.qti.hardware.cacert.server

com.quicinc.voice.activation
#
!com.qualcomm.qti.telephonyservice
"
 com.qualcomm.qti.performancemode

com.android.browser

com.meizu.flyme.directservice
 
com.qualcomm.qti.ridemodeaudio

vendor.qti.iwlan
"
 com.google.android.configupdater

com.android.soundrecorder

com.qualcomm.uimremoteserver

android.qvaoverlay.common
$
"com.android.safetycenter.resources
$
"com.android.providers.downloads.ui

com.android.vending

com.android.pacprocessor

com.android.simappdialog

com.android.networkstack

android.overlay.common
$
"com.android.connectivity.resources
4
2com.android.internal.display.cutout.emulation.hole
4
2com.android.internal.display.cutout.emulation.tall

com.android.modulemetadata

com.android.certinstaller

com.android.carrierconfig

com.meizu.assistant

com.qidian.QDReader

com.wapi.wapicertmanage
2
0com.android.internal.systemui.navbar.threebutton
)
'com.qti.qualcomm.datastatusnotification

com.android.wifi.dialog

org.lsposed.manager
	
android

com.qualcomm.wfd.service

com.meizu.feedback

android.miui.overlay

com.meizu.media.camera

com.qti.qualcomm.deviceinfo

com.rongcard.eid

com.meizu.mstore

com.android.egg

com.android.mms

com.android.mtp

com.android.nfc

com.android.ons

com.android.stk

com.meizu.net.search

com.android.backupconfirm

com.sidesand.millet

com.meizu.perfui

com.meizu.picker

xyz.chenzyadb.cu_toolbox

com.meizu.sceneinfo

com.android.provision

org.codeaurora.ims

com.meizu.notepaper

com.meizu.flyme.calculator
-
+com.google.android.overlay.gmsconfig.common

github.tornaco.android.thanos
#
!com.android.settings.intelligence

com.android.calendar
#
!com.meizu.activeviewlivewallpaper
?
=com.android.internal.systemui.navbar.gestural_extra_wide_back

com.meizu.safe
#
!com.miui.systemui.devices.overlay
$
"com.qualcomm.qti.dynamicddsservice

com.qualcomm.qti.xrvd.service

com.qualcomm.qcrilmsgtunnel

com.meizu.flyme.toolbox
 
com.meizu.connectivitysettings
 
com.android.providers.settings
!
com.android.sharedstoragebackup

com.android.printspooler
+
)com.android.wifi.resources.overlay.common

cn.wps.moffice.lite.meizu

com.meizu.wallpapersetting

org.ifaa.aidl.manager

com.android.dreams.basic

com.android.incallui

com.android.se

com.android.inputdevices

com.fido.asm

com.meizu.flyme.sdkstage

com.flyme.systemuiex

com.android.bips

com.qti.dpmserviceapp

com.meizu.gamecenter.service

com.ibimuyu.lockscreen

com.qti.xdivert

com.android.musicfx
%
#com.android.settings.overlay.common
#
!com.android.cellbroadcastreceiver

com.google.android.webview

com.android.server.telecom
"
 com.android.cellbroadcastservice

com.android.keychain

com.qti.snapdragon.qdcm_ff

com.android.dialer

com.flyme.systemuitools

com.ss.android.ugc.aweme

com.google.android.gms

com.google.android.gsf

com.meizu.account

android.ext.services

com.android.wifi.resources
"
 com.android.phone.overlay.common
*
(com.android.carrierconfig.overlay.common

com.android.calllogbackup
!
com.google.android.partnersetup
%
#com.android.systemui.overlay.common

com.android.cameraextensions

com.ss.android.auto
+
)com.android.server.telecom.overlay.common

com.android.localtransport

com.meizu.facerecognition

com.android.packageinstaller
*
(com.google.android.overlay.gmsconfig.gsa

com.android.carrierdefaultapp
 
com.qualcomm.qti.powersavemode
$
"com.qualcomm.qti.remoteSimlockAuth

com.flyme.safebox
*
(com.qualcomm.qti.devicestatisticsservice
(
&com.android.theme.font.notoserifsource

com.meizu.media.gallery

com.android.proxyhandler
9
7com.android.internal.display.cutout.emulation.waterfall
%
#com.qualcomm.qti.workloadclassifier

com.android.nearby.halfsheet

com.flyme.scanner

com.topjohnwu.magisk
0
.com.google.android.printservice.recommendation

com.absinthe.anywhere_
*
(com.google.android.syncadapters.calendar

com.meizu.alphame
!
com.android.managedprovisioning
$
"com.android.networkstack.tethering

com.android.soundpicker

com.meizu.dataservice

com.tencent.soter.soterserver

com.flyme.netadmin

com.android.dreams.phototable
 
com.goodix.fingerprint.setting

com.upuphone.easyshare

com.zhihu.android

com.meizu.remotecooperation
!
com.meizu.telephonyengineermode

com.android.smspush

com.coolapk.market
"
 com.android.wallpaper.livepicker

com.meizu.flyme.find
*
(com.android.cellbroadcastreceiver.module

com.meizu.voiceassistant
#
!com.android.imsserviceentitlement

com.meizu.cloud

com.meizu.setup

com.meizu.share

com.meizu.media.imageservice

com.android.storagemanager

com.android.bookmarkprovider

com.android.settings

com.qualcomm.qti.cne

com.qualcomm.qti.ims

com.qualcomm.qti.lpa

com.qualcomm.qti.sva

com.qualcomm.qti.uim

com.meizu.battery

com.jingdong.app.mall

org.mipay.android.manager

com.meizu.mzsyncservice

com.meizu.privacy

com.meizu.datamigration

com.autonavi.minimap

com.meizu.suggestion

com.meizu.location

com.android.cts.ctsshim

com.android.remoteprovisioner

com.flyme.alivewallpaper

com.qualcomm.qti.uimGbaApp
+
)com.miui.systemui.overlay.devices.android

com.android.vpndialogs

youlinw.settings.Overlay

com.meizu.meizuuwbtest

com.meizu.flyme.service.find

com.android.phone

com.meizu.mzbasestationsafe

com.android.shell

com.android.sdksandbox

com.android.wallpaperbackup
%
#com.android.providers.blockednumber
&
$com.android.providers.userdictionary
$
"com.android.providers.media.module

com.android.emergency

com.meizu.customizecenter

com.android.hotspot2.osulogin

com.qualcomm.qti.xrcb
/
-com.android.internal.systemui.navbar.gestural

com.android.location.fused

com.meizu.flyme.gamecenter

com.android.systemui

com.meizu.callsetting
"
 com.android.bluetoothmidiservice
 
com.qualcomm.qti.poweroffalarm

com.meizu.netcontactservice

com.qti.phone
"
 com.android.permissioncontroller

com.android.traceur

com.flyme.auto.launcherflow

com.qti.dcf

com.qti.qcc

com.qualcomm.qtil.aptxui
.
,com.android.ondevicepersonalization.services

com.qualcomm.qtil.btdsda

com.android.bluetooth
"
 com.sohu.inputmethod.sogou.meizu

com.qualcomm.timeservice

com.qualcomm.atfwd

com.qualcomm.embms
 
com.android.providers.contacts

vendor.qti.imsrcs

tv.danmaku.bili
 
com.android.captiveportallogin
;
9com.android.internal.systemui.navbar.gestural_narrow_back

com.meizu.flyme.weather
2
0com.android.cellbroadcastreceiver.overlay.common
%
#com.flyme.telecom.usagedata.service
 
com.meizu.net.nativelockscreenAll 