��
�

com.jozein.xedge

tornaco.apps.shortx

com.scb.breezebanking.hk

github.tornaco.android.thanos
$
"com.paloaltonetworks.globalprotect

com.topjohnwu.magisk

com.coolapk.market

com.jozein.xedgepro

tv.danmaku.biliUser 
�{
2
0com.bootleggers.shishufied.clockfont.alienleague
8
6com.android.internal.display.cutout.emulation.noCutout
%
#com.android.theme.font.sanfrancisco
!
com.google.android.carriersetup

com.android.cts.priv.ctsshim

com.android.theme.icon.leaf

org.evolution.easteregg

com.android.uwb.resources
6
4com.android.internal.display.cutout.emulation.corner
(
&com.android.settings.overlay.pixel2022

com.evolution.customization

com.android.adservices.api
!
com.android.theme.font.storopia
6
4com.android.internal.display.cutout.emulation.double
,
*com.google.android.overlay.pixelconfig2018
,
*com.google.android.overlay.pixelconfig2019
!
com.android.providers.telephony
$
"com.google.android.carrierlocation

com.android.dynsystem
.
,com.android.theme.icon_pack.outline.settings
7
5com.android.theme.lockscreen_clock_font.lgsmartgothic
1
/com.google.android.pixel.setupwizard.evolutionx
 
com.android.sdm.plugins.connmo

com.android.theme.icon.pebble
)
'com.google.android.googlequicksearchbox
"
 com.android.theme.font.simpleday
 
com.android.providers.calendar
#
!com.android.system.navbar.android
7
5com.google.android.googlequicksearchbox.nga_resources

com.android.providers.media
 
com.google.pixel.livewallpaper

com.stevesoltys.seedvault

com.android.theme.icon.square
'
%com.google.android.onetimeinitializer

com.google.android.ext.shared
9
7com.android.internal.systemui.navbar.gestural_wide_back

com.android.theme.icon.vessel
1
/com.evolutionx.android.overlay.evolutionxconfig
-
+com.android.theme.icon_pack.victor.settings
)
'com.google.android.apps.diagnosticstool
.
,com.android.theme.icon_pack.acherus.systemui
$
"com.google.android.apps.cameralite

com.google.android.flipendo
.
,com.android.theme.icon_pack.rounded.systemui
0
.com.bootleggers.shishufied.clockfont.bignoodle
$
"com.android.theme.icon.taperedrect
)
'com.android.theme.icon_pack.oos.android
2
0com.android.theme.lockscreen_clock_font.storopia

com.tenx.systemui.signalbar_a

com.tenx.systemui.signalbar_b

com.tenx.systemui.signalbar_c

com.tenx.systemui.signalbar_d

com.tenx.systemui.signalbar_e

com.tenx.systemui.signalbar_f

com.tenx.systemui.signalbar_g

com.tenx.systemui.signalbar_h
 
com.android.theme.font.manrope
"
 com.android.theme.font.nokiapure

com.android.externalstorage
*
(com.android.theme.icon_pack.oos.settings

com.android.htmlviewer
"
 com.android.theme.font.oneuisans
 
com.android.bluetooth.bthelper
$
"com.android.companiondevicemanager

com.android.mms.service
"
 com.android.theme.font.comfortaa
!
com.android.providers.downloads
.
,com.android.theme.icon_pack.outline.systemui
3
1com.android.systemui.auto_generated_rro_product__
#
!com.google.android.apps.messaging
"
 com.android.theme.font.comicsans
 
com.google.android.soundpicker
-
+com.android.theme.icon_pack.rounded.android
(
&com.android.system.monet.snowpaintdrop
!
com.android.theme.font.amarante
!
com.android.theme.font.aclonica
#
!com.qualcomm.qti.telephonyservice
5
3com.android.theme.lockscreen_clock_font.oneplussans
,
*com.bootleggers.shishufied.clockfont.union
,
*com.bootleggers.shishufied.clockfont.vibur
4
2com.android.theme.lockscreen_clock_font.accuratist
+
)com.android.theme.font.nothingdotheadline
-
+com.android.theme.icon_pack.victor.systemui
2
0com.android.theme.icon_pack.circular.themepicker
2
0com.bootleggers.shishufied.clockfont.cherryswash

org.evolution.ota

vendor.qti.iwlan
"
 com.google.android.configupdater
*
(com.google.android.overlay.googlewebview
2
0com.android.systemui.plugin.globalactions.wallet

com.google.ar.core
$
"com.android.safetycenter.resources
 
com.android.system.monet.vivid
$
"com.android.providers.downloads.ui

com.android.vending

com.android.pacprocessor

com.android.simappdialog

com.android.networkstack
3
1com.android.theme.lockscreen_clock_font.coolstory
$
"com.android.theme.font.harmonysans
*
(com.android.theme.icon_pack.oos.systemui
3
1com.google.android.overlay.pixelconfig2019midyear

android.overlay.common
$
"com.android.connectivity.resources

ink.kscope.parallelspace
2
0com.android.theme.lockscreen_clock_font.amarante
4
2com.android.theme.lockscreen_clock_font.grandhotel
4
2com.android.internal.display.cutout.emulation.hole
4
2com.android.internal.display.cutout.emulation.tall
4
2com.android.internal.display.cutout.emulation.wide
B
@com.android.internal.display.cutout.emulation.notchbarkillerleft
2
0com.android.theme.lockscreen_clock_font.aclonica
"
 com.android.networkstack.overlay

com.android.modulemetadata

com.android.certinstaller

com.android.carrierconfig
$
"com.google.android.marvin.talkback
2
0com.android.internal.systemui.navbar.threebutton

com.android.wifi.dialog
	
android
'
%com.android.hotwordenrollment.xgoogle
-
+com.bootleggers.shishufied.clockfont.ginora
*
(com.google.android.apps.privacy.wildlife
&
$com.google.android.pixel.setupwizard
.
,com.android.theme.lockscreen_clock_font.lato
.
,com.android.theme.icon_pack.rounded.launcher
#
!com.android.systemui.signalbar_aa
#
!com.android.systemui.signalbar_bb
#
!com.android.systemui.signalbar_cc
#
!com.android.systemui.signalbar_dd
#
!com.android.systemui.signalbar_ee
*
(com.android.theme.icon_pack.kai.settings
#
!com.android.theme.font.sonysketch
-
+com.android.theme.icon_pack.acherus.android

com.android.egg

com.android.mtp

com.android.nfc

com.android.ons

com.android.stk

com.android.launcher3

com.android.theme.font.cocon

com.android.theme.font.fucek

com.android.theme.font.inter

com.android.theme.font.oduda

com.android.backupconfirm
"
 com.android.theme.font.fluidsans
!
com.android.theme.font.jtleonor
!
com.android.theme.font.arvolato

com.google.android.deskclock

org.protonaosp.deviceconfig
#
!com.android.theme.font.cagliostro
0
.com.android.internal.systemui.navbar.twobutton
"
 com.android.theme.font.lemonmilk
 
com.android.systemui.wifibar_i

org.codeaurora.ims

com.android.statementservice
'
%com.android.theme.icon.roundedhexagon

com.evolution.udfps.resources

com.google.android.as

org.calyxos.backup.contacts
%
#com.android.theme.font.oneplusslate
1
/com.bootleggers.shishufied.clockfont.nothingdot

org.evolutionx.papers
*
(com.android.theme.icon_pack.sam.settings
.
,com.google.android.apps.security.securityhub
!
com.google.android.turboadapter
6
4com.android.theme.lockscreen_clock_font.oneplusslate
)
'com.android.managedprovisioning.overlay
 
com.android.system.navbar.asus
 
com.android.system.navbar.moto
?
=com.android.internal.systemui.navbar.gestural_extra_wide_back
-
+com.android.theme.icon_pack.kai.themepicker
 
com.google.android.setupwizard
!
com.android.theme.font.fifa2018
&
$com.android.theme.font.productsansvh

com.android.theme.icon.heart
#
!com.android.theme.font.nothingdot
/
-org.pixelexperience.faceunlock.overlay.common

com.qualcomm.qcrilmsgtunnel
 
com.android.providers.settings
!
com.android.sharedstoragebackup
-
+com.android.theme.icon_pack.victor.launcher

com.verizon.services

com.android.printspooler
(
&com.android.hotwordenrollment.okgoogle
-
+com.android.theme.icon_pack.filled.settings
+
)com.android.wifi.resources.overlay.common

com.android.dreams.basic
%
#dev.kdrag0n.dyntheme.privileged.sys

com.google.android.as.oss
*
(com.android.theme.icon_pack.kai.systemui
!
com.android.theme.font.reemkufi

com.android.se

com.android.inputdevices
#
!com.google.android.apps.wellbeing

com.google.android.dialer
*
(com.android.theme.icon_pack.oos.launcher

com.android.bips
=
;com.google.audio.hearing.visualization.accessibility.scribe
"
 com.android.theme.icon.stretched

com.qti.dpmserviceapp
#
!com.google.android.apps.nbu.files
-
+com.android.theme.icon_pack.oos.themepicker
1
/com.bootleggers.shishufied.clockfont.googlesans
/
-com.android.theme.icon_pack.circular.settings
1
/com.google.android.accessibility.soundamplifier
-
+com.android.theme.icon_pack.outline.android
!
com.android.theme.font.cooljazz
2
0com.android.theme.lockscreen_clock_font.fifa2018

com.android.musicfx
%
#com.android.settings.overlay.common
,
*com.google.android.documentsui.theme.pixel

com.android.theme.font.bariol
*
(com.android.theme.icon_pack.sam.systemui
#
!com.android.theme.font.googlesans

com.google.android.markup
#
!com.android.cellbroadcastreceiver

com.google.android.webview
!
com.android.theme.icon.teardrop

com.android.theme.font.exotwo

io.chaldeaprjkt.gamespace
%
#com.google.android.apps.carrier.log
2
0com.android.theme.lockscreen_clock_font.reemkufi
0
.com.bootleggers.shishufied.clockfont.adventpro

com.google.android.contacts
2
0com.bootleggers.shishufied.clockfont.sedgwickave

com.android.server.telecom
"
 com.android.cellbroadcastservice
#
!com.android.system.monet.expresso
1
/com.android.theme.icon_pack.rounded.themepicker
!
com.android.system.navbar.nexus
!
com.android.system.navbar.oneui

com.android.keychain
!
com.android.system.navbar.sammy
!
com.android.system.navbar.tecno
)
'com.google.android.overlay.googleconfig
+
)com.android.wifi.resources.overlay.target

com.google.android.calculator

com.android.chrome
-
+com.android.theme.icon_pack.filled.systemui
%
#com.google.android.packageinstaller
-
+com.google.android.apps.customization.pixel

com.google.android.gms

com.google.android.gsf

com.google.android.ims

com.google.android.tag

com.google.android.tts
 
com.android.system.theme.black
 
com.android.system.theme.clear

android.ext.services

com.android.wifi.resources
"
 com.android.phone.overlay.common
*
(com.android.carrierconfig.overlay.common

com.android.calllogbackup
!
com.google.android.partnersetup
%
#com.android.systemui.overlay.common

com.android.cameraextensions

com.android.theme.font.misans
!
com.android.theme.font.opposans
)
'com.google.android.apps.wallpaper.pixel

com.android.localtransport
#
!com.android.theme.font.samsungone

com.android.theme.font.nunito

com.android.carrierdefaultapp

com.dsi.ant.server

com.android.theme.font.oswald
"
 com.android.theme.font.coolstory
)
'com.android.theme.icon_pack.sam.android
,
*com.android.theme.icon_pack.filled.android

com.android.proxyhandler
1
/com.android.theme.lockscreen_clock_font.linotte
!
com.android.theme.font.rosemary

com.android.theme.font.quando
9
7com.android.internal.display.cutout.emulation.waterfall

com.android.intentresolver
5
3com.android.theme.lockscreen_clock_font.harmonysans

com.android.nearby.halfsheet
/
-com.android.theme.icon_pack.circular.systemui

com.tenx.systemui.wifibar_a

com.tenx.systemui.wifibar_b

com.tenx.systemui.wifibar_c

com.tenx.systemui.wifibar_d

com.tenx.systemui.wifibar_e

com.tenx.systemui.wifibar_f

com.tenx.systemui.wifibar_g

com.tenx.systemui.wifibar_h

com.android.theme.font.roboto
 
com.customermobile.preload.vzw
&
$com.android.theme.font.arbutussource
#
!com.android.theme.font.rubikrubik

com.android.theme.font.surfer

com.google.android.feedback
0
.com.google.android.printservice.recommendation
 
com.google.android.apps.photos

com.google.android.calendar
4
2com.android.theme.lockscreen_clock_font.sonysketch
)
'com.android.theme.icon_pack.kai.android

com.android.theme.font.ubuntu
!
com.android.managedprovisioning
$
"com.android.networkstack.tethering

com.android.soundpicker
'
%com.evolution.overlay.immnav.gestural

com.tencent.soter.soterserver
 
com.google.android.documentsui
3
1com.android.theme.lockscreen_clock_font.redressed

com.android.system.navbar.old
(
&com.android.theme.font.robotocondensed
,
*com.google.android.apps.internal.betterbug

com.android.sdm.plugins.dcmo
4
2com.android.theme.lockscreen_clock_font.cagliostro
*
(com.android.theme.icon_pack.kai.launcher

com.android.smspush
"
 com.android.wallpaper.livepicker
0
.com.bootleggers.shishufied.clockfont.snowstorm
2
0com.android.theme.lockscreen_clock_font.rosemary
.
,com.bootleggers.shishufied.clockfont.riviera
&
$com.android.theme.font.lgsmartgothic
 
com.android.theme.icon.hexagon
*
(com.android.cellbroadcastreceiver.module
#
!com.android.imsserviceentitlement
*
(com.android.theme.icon_pack.sam.launcher
/
-com.bootleggers.shishufied.clockfont.headline
,
*com.google.android.apps.cbrsnetworkmonitor
A
?com.android.internal.display.cutout.emulation.avoidAppsInCutout
!
com.android.theme.icon.squircle
$
"com.google.android.gms.supervision
,
*com.android.theme.icon_pack.victor.android
#
!com.android.theme.font.evolvesans

com.android.bookmarkprovider
.
,com.google.android.overlay.pixelconfigcommon

com.android.settings

com.qualcomm.qti.cne
#
!com.android.omadm.service.overlay
"
 com.google.android.wfcactivation
3
1com.android.theme.lockscreen_clock_font.nokiapure
-
+com.android.theme.icon_pack.filled.launcher
*
(com.google.android.settings.intelligence
(
&com.google.android.projection.gearhead

com.google.android.apps.turbo
)
'com.google.android.tetheringentitlement

com.android.omadm.service
/
-com.android.theme.lockscreen_clock_font.cocon
/
-com.android.theme.lockscreen_clock_font.rubik
3
1com.android.theme.lockscreen_clock_font.comfortaa

com.android.cts.ctsshim
5
3com.google.android.apps.wearables.maestro.companion
9
7com.android.theme.lockscreen_clock_font.robotocondensed
0
.com.android.theme.lockscreen_clock_font.bariol
3
1com.android.theme.lockscreen_clock_font.comicsans
/
-com.android.theme.icon_pack.circular.launcher

org.lineageos.settings

com.android.wallpaper
!
com.android.theme.icon.cylinder

com.android.vpndialogs
0
.com.android.theme.lockscreen_clock_font.exotwo
$
"com.android.theme.font.oneplussans

com.google.android.odad
/
-com.bootleggers.shishufied.clockfont.roadrage

com.android.angle

com.android.music

com.android.phone

com.android.shell
0
.com.android.theme.icon_pack.filled.themepicker

com.android.sdksandbox

com.android.wallpaperbackup
%
#com.android.providers.blockednumber
'
%com.google.android.apps.work.clouddpc
&
$com.android.providers.userdictionary
$
"com.android.providers.media.module
-
+com.google.android.apps.carrier.carrierwifi

com.android.emergency

com.android.hotspot2.osulogin
)
'com.google.android.gms.location.history
/
-com.android.internal.systemui.navbar.gestural

com.android.location.fused
0
.com.android.theme.icon_pack.victor.themepicker

com.android.systemui
4
2com.android.theme.lockscreen_clock_font.samsungone
"
 com.android.bluetoothmidiservice
 
com.qualcomm.qti.poweroffalarm
0
.com.android.theme.lockscreen_clock_font.nunito
#
!com.android.theme.font.accuratist

com.qti.phone
0
.com.android.theme.lockscreen_clock_font.oswald
"
 com.android.permissioncontroller
6
4com.google.android.apps.nexuslauncher.custom.overlay
>
<com.android.internal.display.cutout.emulation.notchbarkiller
0
.com.android.theme.lockscreen_clock_font.quando
0
.com.android.theme.lockscreen_clock_font.surfer
+
)com.bootleggers.shishufied.clockfont.biko
&
$android.auto_generated_rro_product__
#
!com.android.system.navbar.oneplus
0
.com.android.theme.lockscreen_clock_font.ubuntu
-
+com.android.theme.icon_pack.sam.themepicker
.
,com.android.ondevicepersonalization.services

com.google.android.apps.gcs

com.android.bluetooth

com.qualcomm.timeservice

com.android.theme.icon.cloudy
 
com.android.providers.contacts
 
com.android.captiveportallogin
 
com.android.theme.font.linotte
 
org.pixelexperience.faceunlock
$
"com.android.theme.icon.roundedrect
#
!com.android.theme.font.grandhotel
;
9com.android.internal.systemui.navbar.gestural_narrow_back

com.android.theme.icon.flower
.
,com.android.theme.icon_pack.rounded.settings
&
$com.google.android.inputmethod.latin
#
!com.google.android.storagemanager
.
,com.android.theme.icon_pack.circular.android
!
com.google.android.apps.restore
"
 com.android.theme.font.redressedSystem 
Game 
s

com.jozein.xedge

tornaco.apps.shortx

github.tornaco.android.thanos

com.jozein.xedgeproXposedModule 
�}
2
0com.bootleggers.shishufied.clockfont.alienleague
8
6com.android.internal.display.cutout.emulation.noCutout
%
#com.android.theme.font.sanfrancisco
!
com.google.android.carriersetup

com.android.cts.priv.ctsshim

com.android.theme.icon.leaf

org.evolution.easteregg

com.android.uwb.resources
6
4com.android.internal.display.cutout.emulation.corner
(
&com.android.settings.overlay.pixel2022

com.evolution.customization

com.android.adservices.api
!
com.android.theme.font.storopia
6
4com.android.internal.display.cutout.emulation.double
,
*com.google.android.overlay.pixelconfig2018
,
*com.google.android.overlay.pixelconfig2019
!
com.android.providers.telephony
$
"com.google.android.carrierlocation

com.android.dynsystem
.
,com.android.theme.icon_pack.outline.settings
7
5com.android.theme.lockscreen_clock_font.lgsmartgothic
1
/com.google.android.pixel.setupwizard.evolutionx
 
com.android.sdm.plugins.connmo

com.android.theme.icon.pebble
)
'com.google.android.googlequicksearchbox
"
 com.android.theme.font.simpleday

com.jozein.xedge
 
com.android.providers.calendar
#
!com.android.system.navbar.android
7
5com.google.android.googlequicksearchbox.nga_resources

com.android.providers.media
 
com.google.pixel.livewallpaper

com.stevesoltys.seedvault

com.android.theme.icon.square
'
%com.google.android.onetimeinitializer

com.google.android.ext.shared
9
7com.android.internal.systemui.navbar.gestural_wide_back

tornaco.apps.shortx

com.android.theme.icon.vessel
1
/com.evolutionx.android.overlay.evolutionxconfig
-
+com.android.theme.icon_pack.victor.settings
)
'com.google.android.apps.diagnosticstool
.
,com.android.theme.icon_pack.acherus.systemui
$
"com.google.android.apps.cameralite

com.google.android.flipendo
.
,com.android.theme.icon_pack.rounded.systemui
0
.com.bootleggers.shishufied.clockfont.bignoodle
$
"com.android.theme.icon.taperedrect
)
'com.android.theme.icon_pack.oos.android
2
0com.android.theme.lockscreen_clock_font.storopia

com.tenx.systemui.signalbar_a

com.tenx.systemui.signalbar_b

com.tenx.systemui.signalbar_c

com.tenx.systemui.signalbar_d

com.tenx.systemui.signalbar_e

com.tenx.systemui.signalbar_f

com.tenx.systemui.signalbar_g

com.tenx.systemui.signalbar_h
 
com.android.theme.font.manrope
"
 com.android.theme.font.nokiapure

com.android.externalstorage
*
(com.android.theme.icon_pack.oos.settings

com.android.htmlviewer
"
 com.android.theme.font.oneuisans
 
com.android.bluetooth.bthelper
$
"com.android.companiondevicemanager

com.android.mms.service

com.scb.breezebanking.hk
"
 com.android.theme.font.comfortaa
!
com.android.providers.downloads
.
,com.android.theme.icon_pack.outline.systemui
3
1com.android.systemui.auto_generated_rro_product__
#
!com.google.android.apps.messaging
"
 com.android.theme.font.comicsans
 
com.google.android.soundpicker
-
+com.android.theme.icon_pack.rounded.android
(
&com.android.system.monet.snowpaintdrop
!
com.android.theme.font.amarante
!
com.android.theme.font.aclonica
#
!com.qualcomm.qti.telephonyservice
5
3com.android.theme.lockscreen_clock_font.oneplussans
,
*com.bootleggers.shishufied.clockfont.union
,
*com.bootleggers.shishufied.clockfont.vibur
4
2com.android.theme.lockscreen_clock_font.accuratist
+
)com.android.theme.font.nothingdotheadline
-
+com.android.theme.icon_pack.victor.systemui
2
0com.android.theme.icon_pack.circular.themepicker
2
0com.bootleggers.shishufied.clockfont.cherryswash

org.evolution.ota

vendor.qti.iwlan
"
 com.google.android.configupdater
*
(com.google.android.overlay.googlewebview
2
0com.android.systemui.plugin.globalactions.wallet

com.google.ar.core
$
"com.android.safetycenter.resources
 
com.android.system.monet.vivid
$
"com.android.providers.downloads.ui

com.android.vending

com.android.pacprocessor

com.android.simappdialog

com.android.networkstack
3
1com.android.theme.lockscreen_clock_font.coolstory
$
"com.android.theme.font.harmonysans
*
(com.android.theme.icon_pack.oos.systemui
3
1com.google.android.overlay.pixelconfig2019midyear

android.overlay.common
$
"com.android.connectivity.resources

ink.kscope.parallelspace
2
0com.android.theme.lockscreen_clock_font.amarante
4
2com.android.theme.lockscreen_clock_font.grandhotel
4
2com.android.internal.display.cutout.emulation.hole
4
2com.android.internal.display.cutout.emulation.tall
4
2com.android.internal.display.cutout.emulation.wide
B
@com.android.internal.display.cutout.emulation.notchbarkillerleft
2
0com.android.theme.lockscreen_clock_font.aclonica
"
 com.android.networkstack.overlay

com.android.modulemetadata

com.android.certinstaller

com.android.carrierconfig
$
"com.google.android.marvin.talkback
2
0com.android.internal.systemui.navbar.threebutton

com.android.wifi.dialog
	
android
'
%com.android.hotwordenrollment.xgoogle
-
+com.bootleggers.shishufied.clockfont.ginora
*
(com.google.android.apps.privacy.wildlife
&
$com.google.android.pixel.setupwizard
.
,com.android.theme.lockscreen_clock_font.lato
.
,com.android.theme.icon_pack.rounded.launcher
#
!com.android.systemui.signalbar_aa
#
!com.android.systemui.signalbar_bb
#
!com.android.systemui.signalbar_cc
#
!com.android.systemui.signalbar_dd
#
!com.android.systemui.signalbar_ee
*
(com.android.theme.icon_pack.kai.settings
#
!com.android.theme.font.sonysketch
-
+com.android.theme.icon_pack.acherus.android

com.android.egg

com.android.mtp

com.android.nfc

com.android.ons

com.android.stk

com.android.launcher3

com.android.theme.font.cocon

com.android.theme.font.fucek

com.android.theme.font.inter

com.android.theme.font.oduda

com.android.backupconfirm
"
 com.android.theme.font.fluidsans
!
com.android.theme.font.jtleonor
!
com.android.theme.font.arvolato

com.google.android.deskclock

org.protonaosp.deviceconfig
#
!com.android.theme.font.cagliostro
0
.com.android.internal.systemui.navbar.twobutton
"
 com.android.theme.font.lemonmilk
 
com.android.systemui.wifibar_i

org.codeaurora.ims

com.android.statementservice
'
%com.android.theme.icon.roundedhexagon

com.evolution.udfps.resources

com.google.android.as

org.calyxos.backup.contacts
%
#com.android.theme.font.oneplusslate
1
/com.bootleggers.shishufied.clockfont.nothingdot

org.evolutionx.papers
*
(com.android.theme.icon_pack.sam.settings
.
,com.google.android.apps.security.securityhub

github.tornaco.android.thanos
!
com.google.android.turboadapter
6
4com.android.theme.lockscreen_clock_font.oneplusslate
)
'com.android.managedprovisioning.overlay
 
com.android.system.navbar.asus
 
com.android.system.navbar.moto
?
=com.android.internal.systemui.navbar.gestural_extra_wide_back
-
+com.android.theme.icon_pack.kai.themepicker
 
com.google.android.setupwizard
!
com.android.theme.font.fifa2018
&
$com.android.theme.font.productsansvh

com.android.theme.icon.heart
#
!com.android.theme.font.nothingdot
/
-org.pixelexperience.faceunlock.overlay.common

com.qualcomm.qcrilmsgtunnel
 
com.android.providers.settings
!
com.android.sharedstoragebackup
-
+com.android.theme.icon_pack.victor.launcher

com.verizon.services

com.android.printspooler
(
&com.android.hotwordenrollment.okgoogle
-
+com.android.theme.icon_pack.filled.settings
+
)com.android.wifi.resources.overlay.common

com.android.dreams.basic
%
#dev.kdrag0n.dyntheme.privileged.sys

com.google.android.as.oss
*
(com.android.theme.icon_pack.kai.systemui
!
com.android.theme.font.reemkufi

com.android.se

com.android.inputdevices
#
!com.google.android.apps.wellbeing

com.google.android.dialer
*
(com.android.theme.icon_pack.oos.launcher

com.android.bips
=
;com.google.audio.hearing.visualization.accessibility.scribe
"
 com.android.theme.icon.stretched

com.qti.dpmserviceapp
#
!com.google.android.apps.nbu.files
-
+com.android.theme.icon_pack.oos.themepicker
1
/com.bootleggers.shishufied.clockfont.googlesans
/
-com.android.theme.icon_pack.circular.settings
1
/com.google.android.accessibility.soundamplifier
-
+com.android.theme.icon_pack.outline.android
!
com.android.theme.font.cooljazz
2
0com.android.theme.lockscreen_clock_font.fifa2018

com.android.musicfx
%
#com.android.settings.overlay.common
,
*com.google.android.documentsui.theme.pixel

com.android.theme.font.bariol
*
(com.android.theme.icon_pack.sam.systemui
#
!com.android.theme.font.googlesans

com.google.android.markup
#
!com.android.cellbroadcastreceiver

com.google.android.webview
!
com.android.theme.icon.teardrop

com.android.theme.font.exotwo

io.chaldeaprjkt.gamespace
%
#com.google.android.apps.carrier.log
2
0com.android.theme.lockscreen_clock_font.reemkufi
0
.com.bootleggers.shishufied.clockfont.adventpro

com.google.android.contacts
2
0com.bootleggers.shishufied.clockfont.sedgwickave

com.android.server.telecom
"
 com.android.cellbroadcastservice
#
!com.android.system.monet.expresso
1
/com.android.theme.icon_pack.rounded.themepicker
!
com.android.system.navbar.nexus
!
com.android.system.navbar.oneui

com.android.keychain
!
com.android.system.navbar.sammy
!
com.android.system.navbar.tecno
)
'com.google.android.overlay.googleconfig
+
)com.android.wifi.resources.overlay.target

com.google.android.calculator

com.android.chrome
-
+com.android.theme.icon_pack.filled.systemui
%
#com.google.android.packageinstaller
-
+com.google.android.apps.customization.pixel

com.google.android.gms

com.google.android.gsf

com.google.android.ims

com.google.android.tag

com.google.android.tts
 
com.android.system.theme.black
 
com.android.system.theme.clear

android.ext.services

com.android.wifi.resources
"
 com.android.phone.overlay.common
*
(com.android.carrierconfig.overlay.common

com.android.calllogbackup
!
com.google.android.partnersetup
%
#com.android.systemui.overlay.common

com.android.cameraextensions

com.android.theme.font.misans
!
com.android.theme.font.opposans
)
'com.google.android.apps.wallpaper.pixel

com.android.localtransport
#
!com.android.theme.font.samsungone

com.android.theme.font.nunito

com.android.carrierdefaultapp

com.dsi.ant.server

com.android.theme.font.oswald
$
"com.paloaltonetworks.globalprotect
"
 com.android.theme.font.coolstory
)
'com.android.theme.icon_pack.sam.android
,
*com.android.theme.icon_pack.filled.android

com.android.proxyhandler
1
/com.android.theme.lockscreen_clock_font.linotte
!
com.android.theme.font.rosemary

com.android.theme.font.quando
9
7com.android.internal.display.cutout.emulation.waterfall

com.android.intentresolver
5
3com.android.theme.lockscreen_clock_font.harmonysans

com.android.nearby.halfsheet
/
-com.android.theme.icon_pack.circular.systemui

com.tenx.systemui.wifibar_a

com.tenx.systemui.wifibar_b

com.tenx.systemui.wifibar_c

com.tenx.systemui.wifibar_d

com.tenx.systemui.wifibar_e

com.tenx.systemui.wifibar_f

com.tenx.systemui.wifibar_g

com.tenx.systemui.wifibar_h

com.android.theme.font.roboto
 
com.customermobile.preload.vzw
&
$com.android.theme.font.arbutussource
#
!com.android.theme.font.rubikrubik

com.android.theme.font.surfer

com.google.android.feedback

com.topjohnwu.magisk
0
.com.google.android.printservice.recommendation
 
com.google.android.apps.photos

com.google.android.calendar
4
2com.android.theme.lockscreen_clock_font.sonysketch
)
'com.android.theme.icon_pack.kai.android

com.android.theme.font.ubuntu
!
com.android.managedprovisioning
$
"com.android.networkstack.tethering

com.android.soundpicker
'
%com.evolution.overlay.immnav.gestural

com.tencent.soter.soterserver
 
com.google.android.documentsui
3
1com.android.theme.lockscreen_clock_font.redressed

com.android.system.navbar.old
(
&com.android.theme.font.robotocondensed
,
*com.google.android.apps.internal.betterbug

com.android.sdm.plugins.dcmo
4
2com.android.theme.lockscreen_clock_font.cagliostro
*
(com.android.theme.icon_pack.kai.launcher

com.android.smspush

com.coolapk.market
"
 com.android.wallpaper.livepicker
0
.com.bootleggers.shishufied.clockfont.snowstorm
2
0com.android.theme.lockscreen_clock_font.rosemary
.
,com.bootleggers.shishufied.clockfont.riviera
&
$com.android.theme.font.lgsmartgothic
 
com.android.theme.icon.hexagon
*
(com.android.cellbroadcastreceiver.module
#
!com.android.imsserviceentitlement
*
(com.android.theme.icon_pack.sam.launcher
/
-com.bootleggers.shishufied.clockfont.headline
,
*com.google.android.apps.cbrsnetworkmonitor
A
?com.android.internal.display.cutout.emulation.avoidAppsInCutout
!
com.android.theme.icon.squircle
$
"com.google.android.gms.supervision
,
*com.android.theme.icon_pack.victor.android
#
!com.android.theme.font.evolvesans

com.android.bookmarkprovider
.
,com.google.android.overlay.pixelconfigcommon

com.android.settings

com.qualcomm.qti.cne
#
!com.android.omadm.service.overlay
"
 com.google.android.wfcactivation
3
1com.android.theme.lockscreen_clock_font.nokiapure
-
+com.android.theme.icon_pack.filled.launcher
*
(com.google.android.settings.intelligence
(
&com.google.android.projection.gearhead

com.google.android.apps.turbo
)
'com.google.android.tetheringentitlement

com.android.omadm.service
/
-com.android.theme.lockscreen_clock_font.cocon
/
-com.android.theme.lockscreen_clock_font.rubik
3
1com.android.theme.lockscreen_clock_font.comfortaa

com.android.cts.ctsshim
5
3com.google.android.apps.wearables.maestro.companion
9
7com.android.theme.lockscreen_clock_font.robotocondensed
0
.com.android.theme.lockscreen_clock_font.bariol
3
1com.android.theme.lockscreen_clock_font.comicsans
/
-com.android.theme.icon_pack.circular.launcher

org.lineageos.settings

com.android.wallpaper
!
com.android.theme.icon.cylinder

com.android.vpndialogs
0
.com.android.theme.lockscreen_clock_font.exotwo
$
"com.android.theme.font.oneplussans

com.google.android.odad
/
-com.bootleggers.shishufied.clockfont.roadrage

com.android.angle

com.android.music

com.android.phone

com.android.shell
0
.com.android.theme.icon_pack.filled.themepicker

com.android.sdksandbox

com.android.wallpaperbackup
%
#com.android.providers.blockednumber
'
%com.google.android.apps.work.clouddpc
&
$com.android.providers.userdictionary
$
"com.android.providers.media.module
-
+com.google.android.apps.carrier.carrierwifi

com.android.emergency

com.android.hotspot2.osulogin
)
'com.google.android.gms.location.history
/
-com.android.internal.systemui.navbar.gestural

com.android.location.fused
0
.com.android.theme.icon_pack.victor.themepicker

com.android.systemui
4
2com.android.theme.lockscreen_clock_font.samsungone
"
 com.android.bluetoothmidiservice
 
com.qualcomm.qti.poweroffalarm
0
.com.android.theme.lockscreen_clock_font.nunito
#
!com.android.theme.font.accuratist

com.qti.phone
0
.com.android.theme.lockscreen_clock_font.oswald
"
 com.android.permissioncontroller
6
4com.google.android.apps.nexuslauncher.custom.overlay

com.jozein.xedgepro
>
<com.android.internal.display.cutout.emulation.notchbarkiller
0
.com.android.theme.lockscreen_clock_font.quando
0
.com.android.theme.lockscreen_clock_font.surfer
+
)com.bootleggers.shishufied.clockfont.biko
&
$android.auto_generated_rro_product__
#
!com.android.system.navbar.oneplus
0
.com.android.theme.lockscreen_clock_font.ubuntu
-
+com.android.theme.icon_pack.sam.themepicker
.
,com.android.ondevicepersonalization.services

com.google.android.apps.gcs

com.android.bluetooth

com.qualcomm.timeservice

com.android.theme.icon.cloudy
 
com.android.providers.contacts

tv.danmaku.bili
 
com.android.captiveportallogin
 
com.android.theme.font.linotte
 
org.pixelexperience.faceunlock
$
"com.android.theme.icon.roundedrect
#
!com.android.theme.font.grandhotel
;
9com.android.internal.systemui.navbar.gestural_narrow_back

com.android.theme.icon.flower
.
,com.android.theme.icon_pack.rounded.settings
&
$com.google.android.inputmethod.latin
#
!com.google.android.storagemanager
.
,com.android.theme.icon_pack.circular.android
!
com.google.android.apps.restore
"
 com.android.theme.font.redressedAll 