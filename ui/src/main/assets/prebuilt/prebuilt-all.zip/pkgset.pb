��
Game
�

com.quark.browser

com.salt.music

bin.mt.plus

com.ss.android.auto

com.topjohnwu.magisk

com.coolapk.market
!
com.googlecode.pythonforandroid

com.netease.cloudmusic

tornaco.apps.shortxUser 
��
2
0com.bootleggers.shishufied.clockfont.alienleague
8
6com.android.internal.display.cutout.emulation.noCutout
%
#com.android.theme.font.sanfrancisco

com.android.cts.priv.ctsshim

com.android.theme.icon.leaf

org.evolution.easteregg

com.android.uwb.resources
6
4com.android.internal.display.cutout.emulation.corner
(
&com.android.settings.overlay.pixel2022

com.android.adservices.api
!
com.android.theme.font.storopia
6
4com.android.internal.display.cutout.emulation.double
,
*com.google.android.overlay.pixelconfig2018
,
*com.google.android.overlay.pixelconfig2019
0
.com.bootleggers.shishufied.clockfont.AlphaWood
!
com.android.providers.telephony
$
"com.google.android.carrierlocation

com.android.dynsystem
.
,com.android.theme.icon_pack.outline.settings
7
5com.android.theme.lockscreen_clock_font.lgsmartgothic

com.android.theme.icon.pebble
)
'com.google.android.googlequicksearchbox
"
 com.android.theme.font.simpleday
 
com.android.providers.calendar
#
!com.android.system.navbar.android
7
5com.google.android.googlequicksearchbox.nga_resources
1
/com.bootleggers.shishufied.clockfont.balticdune

com.android.providers.media

com.android.theme.icon.scroll
 
com.google.pixel.livewallpaper

com.android.theme.icon.square
'
%com.google.android.onetimeinitializer

com.google.android.ext.shared
1
/com.bootleggers.shishufied.clockfont.KGOnlyHope
9
7com.android.internal.systemui.navbar.gestural_wide_back
*
(com.bootleggers.shishufied.font.punkmono
*
(com.bootleggers.shishufied.font.jicaleta

com.android.theme.icon.vessel
1
/com.evolutionx.android.overlay.evolutionxconfig
3
1com.bootleggers.shishufied.clockfont.ZnikomitNo24
-
+com.android.theme.icon_pack.victor.settings
)
'com.google.android.apps.diagnosticstool
-
+com.bootleggers.shishufied.clockfont.Hanged
.
,com.android.theme.icon_pack.acherus.systemui
$
"com.google.android.apps.cameralite

com.google.android.flipendo
.
,com.android.theme.icon_pack.rounded.systemui
0
.com.bootleggers.shishufied.clockfont.bignoodle
$
"com.android.theme.icon.taperedrect
)
'com.android.theme.icon_pack.oos.android
2
0com.android.theme.lockscreen_clock_font.storopia
5
3com.bootleggers.shishufied.clockfont.StandardHeader

com.tenx.systemui.signalbar_a

com.tenx.systemui.signalbar_b

com.tenx.systemui.signalbar_c

com.tenx.systemui.signalbar_d

com.tenx.systemui.signalbar_e

com.tenx.systemui.signalbar_f

com.tenx.systemui.signalbar_g

com.tenx.systemui.signalbar_h
 
com.android.theme.font.manrope
"
 com.android.theme.font.nokiapure
-
+com.bootleggers.shishufied.clockfont.NINJAS

com.android.externalstorage
4
2com.bootleggers.shishufied.clockfont.liquidcrystal
*
(com.android.theme.icon_pack.oos.settings

com.android.htmlviewer
4
2com.bootleggers.shishufied.clockfont.DiscoMidnight
2
0com.bootleggers.shishufied.font.gemsbuckpunkmono
"
 com.android.theme.font.oneuisans
 
com.android.bluetooth.bthelper
$
"com.android.companiondevicemanager

com.android.mms.service
/
-com.bootleggers.shishufied.clockfont.zerofour
"
 com.android.theme.font.comfortaa
4
2com.bootleggers.shishufied.clockfont.c24decoshadow
9
7com.google.android.pixel.setupwizard.evolutionx.overlay
.
,com.bootleggers.shishufied.clockfont.tourney
)
'com.android.theme.font.googlesansmedium
!
com.android.providers.downloads
.
,com.android.theme.icon_pack.outline.systemui
#
!com.google.android.apps.messaging
"
 com.android.theme.font.comicsans
 
com.google.android.soundpicker
-
+com.android.theme.icon_pack.rounded.android
0
.com.bootleggers.shishufied.clockfont.ScrapItUp
(
&com.android.system.monet.snowpaintdrop
/
-com.bootleggers.shishufied.clockfont.museomod
!
com.android.theme.font.amarante
!
com.android.theme.font.aclonica
,
*com.bootleggers.shishufied.clockfont.forta
#
!com.qualcomm.qti.telephonyservice
,
*com.bootleggers.shishufied.clockfont.neon2
5
3com.android.theme.lockscreen_clock_font.oneplussans
,
*com.bootleggers.shishufied.clockfont.union
,
*com.bootleggers.shishufied.clockfont.vibur
1
/com.bootleggers.shishufied.font.blazmahyperwave
4
2com.android.theme.lockscreen_clock_font.accuratist
2
0com.bootleggers.shishufied.clockfont.ACFilmstrip
+
)com.android.theme.font.nothingdotheadline
-
+com.android.theme.icon_pack.victor.systemui
0
.com.bootleggers.shishufied.clockfont.CFBadNews
2
0com.android.theme.icon_pack.circular.themepicker
2
0com.bootleggers.shishufied.clockfont.cherryswash

org.evolution.ota

vendor.qti.iwlan
"
 com.google.android.configupdater
2
0com.bootleggers.shishufied.clockfont.LMSClifford
*
(com.google.android.overlay.googlewebview
2
0com.android.systemui.plugin.globalactions.wallet

com.google.ar.core
(
&com.google.android.apps.emojiwallpaper
$
"com.android.safetycenter.resources
 
com.android.system.monet.vivid
$
"com.android.providers.downloads.ui

com.android.vending

com.android.pacprocessor
/
-com.bootleggers.shishufied.clockfont.ELRIOTT2

com.android.simappdialog

com.android.networkstack
3
1com.android.theme.lockscreen_clock_font.coolstory
$
"com.android.theme.font.harmonysans
*
(com.android.theme.icon_pack.oos.systemui
3
1com.google.android.overlay.pixelconfig2019midyear

android.overlay.common
$
"com.android.connectivity.resources
2
0com.bootleggers.shishufied.clockfont.EasterBunny

ink.kscope.parallelspace
2
0com.android.theme.lockscreen_clock_font.amarante
4
2com.android.theme.lockscreen_clock_font.grandhotel
4
2com.android.internal.display.cutout.emulation.hole
4
2com.android.internal.display.cutout.emulation.tall
4
2com.android.internal.display.cutout.emulation.wide
B
@com.android.internal.display.cutout.emulation.notchbarkillerleft
2
0com.android.theme.lockscreen_clock_font.aclonica
1
/com.bootleggers.shishufied.clockfont.Roundheads
"
 com.android.networkstack.overlay

com.android.modulemetadata

com.android.certinstaller

com.android.carrierconfig
$
"com.google.android.marvin.talkback
-
+com.bootleggers.shishufied.clockfont.dotcom
2
0com.android.internal.systemui.navbar.threebutton
0
.com.bootleggers.shishufied.clockfont.BigCheese
3
1com.bootleggers.shishufied.clockfont.balticbodden

com.android.wifi.dialog
	
android
'
%com.android.hotwordenrollment.xgoogle
-
+com.bootleggers.shishufied.clockfont.ginora
*
(com.google.android.apps.privacy.wildlife
&
$com.google.android.pixel.setupwizard
.
,com.android.theme.lockscreen_clock_font.lato
.
,com.android.theme.icon_pack.rounded.launcher
#
!com.android.systemui.signalbar_aa
#
!com.android.systemui.signalbar_bb
#
!com.android.systemui.signalbar_cc
#
!com.android.systemui.signalbar_dd
#
!com.android.systemui.signalbar_ee
*
(com.android.theme.icon_pack.kai.settings
#
!com.android.theme.font.sonysketch
-
+com.android.theme.icon_pack.acherus.android

com.android.egg

com.android.mtp

com.android.nfc

com.android.ons

com.android.stk

com.android.launcher3

com.android.theme.font.cocon
0
.com.bootleggers.shishufied.clockfont.neptuncat

com.android.theme.font.fucek

com.android.theme.font.inter

com.android.theme.font.oduda

com.android.backupconfirm
"
 com.android.theme.font.fluidsans
+
)com.bootleggers.shishufied.font.cardelina
!
com.android.theme.font.jtleonor
-
+com.bootleggers.shishufied.clockfont.odibee
!
com.android.theme.font.arvolato

com.google.android.deskclock

org.protonaosp.deviceconfig
#
!com.android.theme.font.cagliostro
0
.com.android.internal.systemui.navbar.twobutton
"
 com.android.theme.font.lemonmilk
3
1com.bootleggers.shishufied.clockfont.BunnyRabbits
 
com.android.systemui.wifibar_i
 
com.android.systemui.wifibar_k
 
com.android.systemui.wifibar_l

org.codeaurora.ims

com.android.statementservice
'
%com.android.theme.icon.roundedhexagon

com.evolution.udfps.resources
5
3com.bootleggers.shishufied.clockfont.MessingLettern

com.google.android.as
%
#com.android.theme.font.oneplusslate
1
/com.bootleggers.shishufied.clockfont.nothingdot

org.evolutionx.papers
*
(com.android.theme.icon_pack.sam.settings
.
,com.google.android.apps.security.securityhub
!
com.google.android.turboadapter
2
0com.bootleggers.shishufied.clockfont.rubikglitch
3
1com.bootleggers.shishufied.clockfont.AlphaFlowers
6
4com.android.theme.lockscreen_clock_font.oneplusslate
)
'com.android.managedprovisioning.overlay
-
+com.bootleggers.shishufied.clockfont.vg5000
 
com.android.system.navbar.asus
 
com.android.system.navbar.moto
?
=com.android.internal.systemui.navbar.gestural_extra_wide_back
-
+com.android.theme.icon_pack.kai.themepicker
 
com.google.android.setupwizard
!
com.android.theme.font.fifa2018
&
$com.android.theme.font.productsansvh

com.android.theme.icon.heart
#
!com.android.theme.font.nothingdot

com.android.theme.icon.leafy

com.android.theme.icon.rohie
7
5com.bootleggers.shishufied.clockfont.arcadeinterlaced
/
-org.pixelexperience.faceunlock.overlay.common

com.qualcomm.qcrilmsgtunnel
 
com.android.providers.settings
!
com.android.sharedstoragebackup
-
+com.android.theme.icon_pack.victor.launcher

com.android.printspooler
(
&com.android.hotwordenrollment.okgoogle
/
-com.bootleggers.shishufied.clockfont.xtrusion
-
+com.android.theme.icon_pack.filled.settings
+
)com.android.wifi.resources.overlay.common

com.android.dreams.basic
%
#dev.kdrag0n.dyntheme.privileged.sys

com.google.android.as.oss
+
)com.bootleggers.shishufied.font.cookierun
0
.com.bootleggers.shishufied.clockfont.prodeltco
*
(com.android.theme.icon_pack.kai.systemui
!
com.android.theme.font.reemkufi

com.android.se

com.android.inputdevices
#
!com.google.android.apps.wellbeing

com.google.android.dialer
*
(com.android.theme.icon_pack.oos.launcher
1
/com.bootleggers.shishufied.clockfont.PlaidEvent

com.android.bips
=
;com.google.audio.hearing.visualization.accessibility.scribe
0
.com.bootleggers.shishufied.clockfont.v5prophit
"
 com.android.theme.icon.stretched

com.qti.dpmserviceapp
#
!com.google.android.apps.nbu.files
-
+com.android.theme.icon_pack.oos.themepicker
1
/com.bootleggers.shishufied.clockfont.googlesans
/
-com.android.theme.icon_pack.circular.settings
1
/com.google.android.accessibility.soundamplifier
-
+com.android.theme.icon_pack.outline.android
!
com.android.theme.font.cooljazz
2
0com.android.theme.lockscreen_clock_font.fifa2018

com.google.ambient.streaming

com.android.musicfx
%
#com.android.settings.overlay.common
,
*com.custom.overlay.systemui.signalGradicon
,
*com.google.android.documentsui.theme.pixel

com.android.theme.font.bariol
*
(com.android.theme.icon_pack.sam.systemui
#
!com.android.theme.font.googlesans
/
-com.android.systemui.brightness_slider.filled

com.google.android.markup
#
!com.android.cellbroadcastreceiver

com.google.android.webview
!
com.android.theme.icon.teardrop
*
(com.custom.overlay.systemui.wifiGradicon

com.android.theme.font.exotwo

io.chaldeaprjkt.gamespace
%
#com.google.android.apps.carrier.log
2
0com.android.theme.lockscreen_clock_font.reemkufi
0
.com.bootleggers.shishufied.clockfont.adventpro

com.google.android.contacts

com.android.server.telecom
0
.com.bootleggers.shishufied.clockfont.NeonDisco
"
 com.android.cellbroadcastservice
#
!com.android.system.monet.expresso
1
/com.android.theme.icon_pack.rounded.themepicker
!
com.android.system.navbar.nexus
!
com.android.system.navbar.oneui

com.android.keychain
!
com.android.system.navbar.sammy
!
com.android.system.navbar.tecno
)
'com.google.android.overlay.googleconfig
4
2com.bootleggers.shishufied.clockfont.BetsyFlanagan
+
)com.android.wifi.resources.overlay.target

com.google.android.calculator

com.android.chrome
6
4com.bootleggers.shishufied.clockfont.LowerAtmosphere
4
2com.bootleggers.shishufied.clockfont.lovenessthree
/
-com.bootleggers.shishufied.clockfont.CRACKMAN
-
+com.android.theme.icon_pack.filled.systemui
%
#com.google.android.packageinstaller
-
+com.google.android.apps.customization.pixel

com.google.android.gms

com.google.android.gsf

com.google.android.ims

com.google.android.tag

com.google.android.tts
 
com.android.system.theme.black
 
com.android.system.theme.clear

android.ext.services

com.android.wifi.resources
*
(com.bootleggers.shishufied.clockfont.Cat
"
 com.android.phone.overlay.common
*
(com.android.carrierconfig.overlay.common

com.android.calllogbackup
!
com.google.android.partnersetup
%
#com.android.systemui.overlay.common

com.android.cameraextensions

com.android.theme.font.misans
!
com.android.theme.font.opposans
)
'com.google.android.apps.wallpaper.pixel
3
1com.bootleggers.shishufied.clockfont.BudmoJiggler

com.android.localtransport
-
+com.android.systemui.brightness_slider.acun
-
+com.android.systemui.brightness_slider.bang
-
+com.android.systemui.brightness_slider.thin
#
!com.android.theme.font.samsungone
&
$com.google.android.wallpaper.effects

com.android.theme.font.nunito

com.android.carrierdefaultapp

com.dsi.ant.server

com.android.theme.font.oswald
"
 com.android.theme.font.coolstory
)
'com.android.theme.icon_pack.sam.android
/
-com.bootleggers.shishufied.clockfont.frankfrt
,
*com.android.theme.icon_pack.filled.android

com.android.proxyhandler
1
/com.android.theme.lockscreen_clock_font.linotte
!
com.android.theme.font.rosemary

com.android.theme.font.quando
9
7com.android.internal.display.cutout.emulation.waterfall

com.android.intentresolver
5
3com.android.theme.lockscreen_clock_font.harmonysans

com.android.nearby.halfsheet
;
9com.bootleggers.shishufied.clockfont.GautsMotelUpperRight
/
-com.android.theme.icon_pack.circular.systemui
1
/com.bootleggers.shishufied.clockfont.VTKSDURA3d

com.tenx.systemui.wifibar_a

com.tenx.systemui.wifibar_b

com.tenx.systemui.wifibar_c

com.tenx.systemui.wifibar_d

com.tenx.systemui.wifibar_e

com.tenx.systemui.wifibar_f

com.tenx.systemui.wifibar_g

com.tenx.systemui.wifibar_h

com.android.theme.font.roboto
 
com.customermobile.preload.vzw
&
$com.android.theme.font.arbutussource
#
!com.android.theme.font.rubikrubik

com.android.theme.font.surfer
1
/com.bootleggers.shishufied.clockfont.Brandayolq

com.google.android.feedback
0
.com.google.android.printservice.recommendation
 
com.google.android.apps.photos

com.google.android.calendar
4
2com.android.theme.lockscreen_clock_font.sonysketch
)
'com.android.theme.icon_pack.kai.android

com.android.theme.font.ubuntu
!
com.android.managedprovisioning
$
"com.android.networkstack.tethering

com.android.soundpicker
7
5com.bootleggers.shishufied.clockfont.EditPointsFilled
'
%com.evolution.overlay.immnav.gestural

com.tencent.soter.soterserver
 
com.google.android.documentsui
3
1com.android.theme.lockscreen_clock_font.redressed
2
0com.bootleggers.shishufied.clockfont.Concentrate
/
-com.bootleggers.shishufied.clockfont.Ampad3D2

com.android.system.navbar.old
'
%com.google.android.systemui.gxoverlay
.
,com.bootleggers.shishufied.clockfont.Klyukin
(
&com.android.theme.font.robotocondensed
,
*com.google.android.apps.internal.betterbug
4
2com.android.theme.lockscreen_clock_font.cagliostro
*
(com.android.theme.icon_pack.kai.launcher
*
(com.bootleggers.shishufied.font.justsans

com.android.smspush
1
/com.bootleggers.shishufied.clockfont.QuickSouth
"
 com.android.wallpaper.livepicker
0
.com.bootleggers.shishufied.clockfont.snowstorm
2
0com.android.theme.lockscreen_clock_font.rosemary
+
)com.google.android.flipendo.overlay.pixel
.
,com.bootleggers.shishufied.clockfont.riviera
2
0com.bootleggers.shishufied.clockfont.AlphaClouds
&
$com.android.theme.font.lgsmartgothic
 
com.android.theme.icon.hexagon
*
(com.android.cellbroadcastreceiver.module

com.android.theme.icon.ios
#
!com.android.imsserviceentitlement
6
4com.bootleggers.shishufied.clockfont.permanentmarker
4
2com.bootleggers.shishufied.clockfont.CFOneTwoTrees
*
(com.android.theme.icon_pack.sam.launcher
5
3com.bootleggers.shishufied.clockfont.threedisoblack
0
.com.bootleggers.shishufied.clockfont.Karamuruh
/
-com.bootleggers.shishufied.clockfont.headline
,
*com.google.android.apps.cbrsnetworkmonitor
A
?com.android.internal.display.cutout.emulation.avoidAppsInCutout
!
com.android.theme.icon.squircle
1
/com.bootleggers.shishufied.clockfont.EditPoints
$
"com.google.android.gms.supervision
1
/com.bootleggers.shishufied.clockfont.TH3MACHINE
,
*com.android.theme.icon_pack.victor.android
4
2com.bootleggers.shishufied.clockfont.PlantsLetters
#
!com.android.theme.font.evolvesans

com.android.bookmarkprovider
.
,com.google.android.overlay.pixelconfigcommon

com.android.settings

com.qualcomm.qti.cne
#
!com.android.omadm.service.overlay
-
+com.bootleggers.shishufied.font.circularstd
3
1com.android.theme.lockscreen_clock_font.nokiapure
$
"com.google.android.apps.healthdata
-
+com.android.theme.icon_pack.filled.launcher
0
.com.bootleggers.shishufied.clockfont.mxwasgard
*
(com.google.android.settings.intelligence
(
&com.google.android.projection.gearhead

com.google.android.apps.turbo
4
2com.bootleggers.shishufied.clockfont.threedisobold
/
-com.android.theme.lockscreen_clock_font.cocon
/
-com.android.theme.lockscreen_clock_font.rubik
3
1com.android.theme.lockscreen_clock_font.comfortaa

com.android.cts.ctsshim
5
3com.google.android.apps.wearables.maestro.companion
9
7com.android.theme.lockscreen_clock_font.robotocondensed
2
0com.bootleggers.shishufied.clockfont.balticcoast
2
0com.bootleggers.shishufied.clockfont.AlmonteSnow
2
0com.bootleggers.shishufied.clockfont.balticstorm
0
.com.android.theme.lockscreen_clock_font.bariol
3
1com.android.theme.lockscreen_clock_font.comicsans
/
-com.android.theme.icon_pack.circular.launcher

org.lineageos.settings
0
.com.bootleggers.shishufied.clockfont.munsteria

com.android.wallpaper
!
com.android.theme.icon.cylinder
.
,com.bootleggers.shishufied.clockfont.REMPONK

com.android.vpndialogs
0
.com.android.theme.lockscreen_clock_font.exotwo
5
3com.bootleggers.shishufied.font.giganticfshezaedrus
$
"com.android.theme.font.oneplussans

com.google.android.odad
&
$com.custom.systemui.signalNothingDot
/
-com.bootleggers.shishufied.clockfont.roadrage

com.android.angle

com.android.music

com.android.phone

com.android.shell
0
.com.android.theme.icon_pack.filled.themepicker

com.android.sdksandbox

com.android.wallpaperbackup
%
#com.android.providers.blockednumber
'
%com.google.android.apps.work.clouddpc
&
$com.android.providers.userdictionary
$
"com.android.providers.media.module
1
/com.bootleggers.shishufied.clockfont.Fibography

com.android.emergency
"
 com.android.systemui.signalbar_k
"
 com.android.systemui.signalbar_l
"
 com.android.systemui.signalbar_m
:
8com.bootleggers.shishufied.clockfont.MonbijouxClownpiece

com.android.hotspot2.osulogin
)
'com.google.android.gms.location.history
/
-com.android.internal.systemui.navbar.gestural
2
0com.bootleggers.shishufied.clockfont.Romantiques

com.android.location.fused
0
.com.android.theme.icon_pack.victor.themepicker

com.android.systemui
4
2com.android.theme.lockscreen_clock_font.samsungone
"
 com.android.bluetoothmidiservice
 
com.qualcomm.qti.poweroffalarm
/
-com.bootleggers.shishufied.clockfont.Pinewood
0
.com.android.theme.lockscreen_clock_font.nunito
#
!com.android.theme.font.accuratist

com.qti.phone
0
.com.android.theme.lockscreen_clock_font.oswald
2
0com.bootleggers.shishufied.clockfont.LittleBunny
"
 com.android.permissioncontroller
>
<com.android.internal.display.cutout.emulation.notchbarkiller
0
.com.android.theme.lockscreen_clock_font.quando
"
 com.custom.systemui.signalbar_ab
"
 com.custom.systemui.signalbar_ac
"
 com.custom.systemui.signalbar_ad
"
 com.custom.systemui.signalbar_af
"
 com.custom.systemui.signalbar_ag
"
 com.custom.systemui.signalbar_ai
"
 com.custom.systemui.signalbar_aj
"
 com.custom.systemui.signalbar_ak
"
 com.custom.systemui.signalbar_al
"
 com.custom.systemui.signalbar_am
"
 com.custom.systemui.signalbar_an
"
 com.custom.systemui.signalbar_ao
"
 com.custom.systemui.signalbar_ap
"
 com.custom.systemui.signalbar_aq
"
 com.custom.systemui.signalbar_as
"
 com.custom.systemui.signalbar_au
/
-com.bootleggers.shishufied.clockfont.HotSweat
0
.com.android.theme.lockscreen_clock_font.surfer
+
)com.bootleggers.shishufied.clockfont.biko
1
/com.bootleggers.shishufied.clockfont.Kingthings
#
!com.android.system.navbar.oneplus
0
.com.bootleggers.shishufied.clockfont.SpaceGame
0
.com.android.theme.lockscreen_clock_font.ubuntu
-
+com.android.theme.icon_pack.sam.themepicker
.
,com.android.ondevicepersonalization.services

com.google.android.apps.gcs

com.android.bluetooth

com.qualcomm.timeservice
1
/com.bootleggers.shishufied.clockfont.Floorlight

com.android.theme.icon.cloudy
 
com.android.providers.contacts
$
"com.custom.systemui.wifiNothingDot
 
com.android.captiveportallogin
 
com.android.theme.font.linotte
 
org.pixelexperience.faceunlock
$
"com.android.theme.icon.roundedrect
5
3com.bootleggers.shishufied.clockfont.karmaticarcade
#
!com.android.theme.font.grandhotel
;
9com.android.internal.systemui.navbar.gestural_narrow_back

com.android.theme.icon.flower
.
,com.android.theme.icon_pack.rounded.settings
&
$com.google.android.inputmethod.latin
#
!com.google.android.storagemanager
.
,com.android.theme.icon_pack.circular.android
!
com.google.android.apps.restore
"
 com.android.theme.font.redressedSystem 
'

tornaco.apps.shortxXposedModule 
��
2
0com.bootleggers.shishufied.clockfont.alienleague
8
6com.android.internal.display.cutout.emulation.noCutout
%
#com.android.theme.font.sanfrancisco

com.android.cts.priv.ctsshim

com.android.theme.icon.leaf

com.quark.browser

org.evolution.easteregg

com.android.uwb.resources
6
4com.android.internal.display.cutout.emulation.corner
(
&com.android.settings.overlay.pixel2022

com.android.adservices.api
!
com.android.theme.font.storopia
6
4com.android.internal.display.cutout.emulation.double
,
*com.google.android.overlay.pixelconfig2018
,
*com.google.android.overlay.pixelconfig2019
0
.com.bootleggers.shishufied.clockfont.AlphaWood
!
com.android.providers.telephony
$
"com.google.android.carrierlocation

com.android.dynsystem
.
,com.android.theme.icon_pack.outline.settings
7
5com.android.theme.lockscreen_clock_font.lgsmartgothic

com.android.theme.icon.pebble
)
'com.google.android.googlequicksearchbox
"
 com.android.theme.font.simpleday
 
com.android.providers.calendar
#
!com.android.system.navbar.android
7
5com.google.android.googlequicksearchbox.nga_resources
1
/com.bootleggers.shishufied.clockfont.balticdune

com.android.providers.media

com.android.theme.icon.scroll
 
com.google.pixel.livewallpaper

com.android.theme.icon.square
'
%com.google.android.onetimeinitializer

com.google.android.ext.shared
1
/com.bootleggers.shishufied.clockfont.KGOnlyHope
9
7com.android.internal.systemui.navbar.gestural_wide_back
*
(com.bootleggers.shishufied.font.punkmono
*
(com.bootleggers.shishufied.font.jicaleta

com.android.theme.icon.vessel
1
/com.evolutionx.android.overlay.evolutionxconfig
3
1com.bootleggers.shishufied.clockfont.ZnikomitNo24
-
+com.android.theme.icon_pack.victor.settings
)
'com.google.android.apps.diagnosticstool
-
+com.bootleggers.shishufied.clockfont.Hanged
.
,com.android.theme.icon_pack.acherus.systemui
$
"com.google.android.apps.cameralite

com.google.android.flipendo
.
,com.android.theme.icon_pack.rounded.systemui
0
.com.bootleggers.shishufied.clockfont.bignoodle
$
"com.android.theme.icon.taperedrect
)
'com.android.theme.icon_pack.oos.android
2
0com.android.theme.lockscreen_clock_font.storopia
5
3com.bootleggers.shishufied.clockfont.StandardHeader

com.tenx.systemui.signalbar_a

com.tenx.systemui.signalbar_b

com.tenx.systemui.signalbar_c

com.tenx.systemui.signalbar_d

com.tenx.systemui.signalbar_e

com.tenx.systemui.signalbar_f

com.tenx.systemui.signalbar_g

com.tenx.systemui.signalbar_h
 
com.android.theme.font.manrope
"
 com.android.theme.font.nokiapure
-
+com.bootleggers.shishufied.clockfont.NINJAS

com.android.externalstorage
4
2com.bootleggers.shishufied.clockfont.liquidcrystal
*
(com.android.theme.icon_pack.oos.settings

com.android.htmlviewer
4
2com.bootleggers.shishufied.clockfont.DiscoMidnight
2
0com.bootleggers.shishufied.font.gemsbuckpunkmono
"
 com.android.theme.font.oneuisans
 
com.android.bluetooth.bthelper
$
"com.android.companiondevicemanager

com.android.mms.service
/
-com.bootleggers.shishufied.clockfont.zerofour
"
 com.android.theme.font.comfortaa
4
2com.bootleggers.shishufied.clockfont.c24decoshadow
9
7com.google.android.pixel.setupwizard.evolutionx.overlay
.
,com.bootleggers.shishufied.clockfont.tourney
)
'com.android.theme.font.googlesansmedium
!
com.android.providers.downloads
.
,com.android.theme.icon_pack.outline.systemui
#
!com.google.android.apps.messaging
"
 com.android.theme.font.comicsans
 
com.google.android.soundpicker
-
+com.android.theme.icon_pack.rounded.android
0
.com.bootleggers.shishufied.clockfont.ScrapItUp
(
&com.android.system.monet.snowpaintdrop
/
-com.bootleggers.shishufied.clockfont.museomod
!
com.android.theme.font.amarante
!
com.android.theme.font.aclonica
,
*com.bootleggers.shishufied.clockfont.forta
#
!com.qualcomm.qti.telephonyservice
,
*com.bootleggers.shishufied.clockfont.neon2
5
3com.android.theme.lockscreen_clock_font.oneplussans
,
*com.bootleggers.shishufied.clockfont.union
,
*com.bootleggers.shishufied.clockfont.vibur
1
/com.bootleggers.shishufied.font.blazmahyperwave
4
2com.android.theme.lockscreen_clock_font.accuratist
2
0com.bootleggers.shishufied.clockfont.ACFilmstrip
+
)com.android.theme.font.nothingdotheadline
-
+com.android.theme.icon_pack.victor.systemui
0
.com.bootleggers.shishufied.clockfont.CFBadNews
2
0com.android.theme.icon_pack.circular.themepicker
2
0com.bootleggers.shishufied.clockfont.cherryswash

org.evolution.ota

vendor.qti.iwlan
"
 com.google.android.configupdater
2
0com.bootleggers.shishufied.clockfont.LMSClifford
*
(com.google.android.overlay.googlewebview
2
0com.android.systemui.plugin.globalactions.wallet

com.google.ar.core
(
&com.google.android.apps.emojiwallpaper
$
"com.android.safetycenter.resources
 
com.android.system.monet.vivid
$
"com.android.providers.downloads.ui

com.android.vending

com.android.pacprocessor
/
-com.bootleggers.shishufied.clockfont.ELRIOTT2

com.android.simappdialog

com.android.networkstack
3
1com.android.theme.lockscreen_clock_font.coolstory
$
"com.android.theme.font.harmonysans
*
(com.android.theme.icon_pack.oos.systemui
3
1com.google.android.overlay.pixelconfig2019midyear

android.overlay.common
$
"com.android.connectivity.resources
2
0com.bootleggers.shishufied.clockfont.EasterBunny

ink.kscope.parallelspace
2
0com.android.theme.lockscreen_clock_font.amarante
4
2com.android.theme.lockscreen_clock_font.grandhotel
4
2com.android.internal.display.cutout.emulation.hole
4
2com.android.internal.display.cutout.emulation.tall
4
2com.android.internal.display.cutout.emulation.wide
B
@com.android.internal.display.cutout.emulation.notchbarkillerleft
2
0com.android.theme.lockscreen_clock_font.aclonica
1
/com.bootleggers.shishufied.clockfont.Roundheads
"
 com.android.networkstack.overlay

com.android.modulemetadata

com.android.certinstaller

com.android.carrierconfig
$
"com.google.android.marvin.talkback
-
+com.bootleggers.shishufied.clockfont.dotcom
2
0com.android.internal.systemui.navbar.threebutton
0
.com.bootleggers.shishufied.clockfont.BigCheese
3
1com.bootleggers.shishufied.clockfont.balticbodden

com.android.wifi.dialog
	
android
'
%com.android.hotwordenrollment.xgoogle
-
+com.bootleggers.shishufied.clockfont.ginora
*
(com.google.android.apps.privacy.wildlife
&
$com.google.android.pixel.setupwizard
.
,com.android.theme.lockscreen_clock_font.lato
.
,com.android.theme.icon_pack.rounded.launcher
#
!com.android.systemui.signalbar_aa
#
!com.android.systemui.signalbar_bb
#
!com.android.systemui.signalbar_cc
#
!com.android.systemui.signalbar_dd
#
!com.android.systemui.signalbar_ee
*
(com.android.theme.icon_pack.kai.settings
#
!com.android.theme.font.sonysketch
-
+com.android.theme.icon_pack.acherus.android

com.salt.music

com.android.egg

com.android.mtp

com.android.nfc

com.android.ons

com.android.stk

com.android.launcher3

com.android.theme.font.cocon
0
.com.bootleggers.shishufied.clockfont.neptuncat

com.android.theme.font.fucek

com.android.theme.font.inter

com.android.theme.font.oduda

com.android.backupconfirm
"
 com.android.theme.font.fluidsans
+
)com.bootleggers.shishufied.font.cardelina
!
com.android.theme.font.jtleonor
-
+com.bootleggers.shishufied.clockfont.odibee
!
com.android.theme.font.arvolato

com.google.android.deskclock

org.protonaosp.deviceconfig
#
!com.android.theme.font.cagliostro
0
.com.android.internal.systemui.navbar.twobutton
"
 com.android.theme.font.lemonmilk
3
1com.bootleggers.shishufied.clockfont.BunnyRabbits
 
com.android.systemui.wifibar_i
 
com.android.systemui.wifibar_k
 
com.android.systemui.wifibar_l

org.codeaurora.ims

com.android.statementservice
'
%com.android.theme.icon.roundedhexagon

com.evolution.udfps.resources
5
3com.bootleggers.shishufied.clockfont.MessingLettern

com.google.android.as

bin.mt.plus
%
#com.android.theme.font.oneplusslate
1
/com.bootleggers.shishufied.clockfont.nothingdot

org.evolutionx.papers
*
(com.android.theme.icon_pack.sam.settings
.
,com.google.android.apps.security.securityhub
!
com.google.android.turboadapter
2
0com.bootleggers.shishufied.clockfont.rubikglitch
3
1com.bootleggers.shishufied.clockfont.AlphaFlowers
6
4com.android.theme.lockscreen_clock_font.oneplusslate
)
'com.android.managedprovisioning.overlay
-
+com.bootleggers.shishufied.clockfont.vg5000
 
com.android.system.navbar.asus
 
com.android.system.navbar.moto
?
=com.android.internal.systemui.navbar.gestural_extra_wide_back
-
+com.android.theme.icon_pack.kai.themepicker
 
com.google.android.setupwizard
!
com.android.theme.font.fifa2018
&
$com.android.theme.font.productsansvh

com.android.theme.icon.heart
#
!com.android.theme.font.nothingdot

com.android.theme.icon.leafy

com.android.theme.icon.rohie
7
5com.bootleggers.shishufied.clockfont.arcadeinterlaced
/
-org.pixelexperience.faceunlock.overlay.common

com.qualcomm.qcrilmsgtunnel
 
com.android.providers.settings
!
com.android.sharedstoragebackup
-
+com.android.theme.icon_pack.victor.launcher

com.android.printspooler
(
&com.android.hotwordenrollment.okgoogle
/
-com.bootleggers.shishufied.clockfont.xtrusion
-
+com.android.theme.icon_pack.filled.settings
+
)com.android.wifi.resources.overlay.common

com.android.dreams.basic
%
#dev.kdrag0n.dyntheme.privileged.sys

com.google.android.as.oss
+
)com.bootleggers.shishufied.font.cookierun
0
.com.bootleggers.shishufied.clockfont.prodeltco
*
(com.android.theme.icon_pack.kai.systemui
!
com.android.theme.font.reemkufi

com.android.se

com.android.inputdevices
#
!com.google.android.apps.wellbeing

com.google.android.dialer
*
(com.android.theme.icon_pack.oos.launcher
1
/com.bootleggers.shishufied.clockfont.PlaidEvent

com.android.bips
=
;com.google.audio.hearing.visualization.accessibility.scribe
0
.com.bootleggers.shishufied.clockfont.v5prophit
"
 com.android.theme.icon.stretched

com.qti.dpmserviceapp
#
!com.google.android.apps.nbu.files
-
+com.android.theme.icon_pack.oos.themepicker
1
/com.bootleggers.shishufied.clockfont.googlesans
/
-com.android.theme.icon_pack.circular.settings
1
/com.google.android.accessibility.soundamplifier
-
+com.android.theme.icon_pack.outline.android
!
com.android.theme.font.cooljazz
2
0com.android.theme.lockscreen_clock_font.fifa2018

com.google.ambient.streaming

com.android.musicfx
%
#com.android.settings.overlay.common
,
*com.custom.overlay.systemui.signalGradicon
,
*com.google.android.documentsui.theme.pixel

com.android.theme.font.bariol
*
(com.android.theme.icon_pack.sam.systemui
#
!com.android.theme.font.googlesans
/
-com.android.systemui.brightness_slider.filled

com.google.android.markup
#
!com.android.cellbroadcastreceiver

com.google.android.webview
!
com.android.theme.icon.teardrop
*
(com.custom.overlay.systemui.wifiGradicon

com.android.theme.font.exotwo

io.chaldeaprjkt.gamespace
%
#com.google.android.apps.carrier.log
2
0com.android.theme.lockscreen_clock_font.reemkufi
0
.com.bootleggers.shishufied.clockfont.adventpro

com.google.android.contacts

com.android.server.telecom
0
.com.bootleggers.shishufied.clockfont.NeonDisco
"
 com.android.cellbroadcastservice
#
!com.android.system.monet.expresso
1
/com.android.theme.icon_pack.rounded.themepicker
!
com.android.system.navbar.nexus
!
com.android.system.navbar.oneui

com.android.keychain
!
com.android.system.navbar.sammy
!
com.android.system.navbar.tecno
)
'com.google.android.overlay.googleconfig
4
2com.bootleggers.shishufied.clockfont.BetsyFlanagan
+
)com.android.wifi.resources.overlay.target

com.google.android.calculator

com.android.chrome
6
4com.bootleggers.shishufied.clockfont.LowerAtmosphere
4
2com.bootleggers.shishufied.clockfont.lovenessthree
/
-com.bootleggers.shishufied.clockfont.CRACKMAN
-
+com.android.theme.icon_pack.filled.systemui
%
#com.google.android.packageinstaller
-
+com.google.android.apps.customization.pixel

com.google.android.gms

com.google.android.gsf

com.google.android.ims

com.google.android.tag

com.google.android.tts
 
com.android.system.theme.black
 
com.android.system.theme.clear

android.ext.services

com.android.wifi.resources
*
(com.bootleggers.shishufied.clockfont.Cat
"
 com.android.phone.overlay.common
*
(com.android.carrierconfig.overlay.common

com.android.calllogbackup
!
com.google.android.partnersetup
%
#com.android.systemui.overlay.common

com.android.cameraextensions

com.android.theme.font.misans
!
com.android.theme.font.opposans
)
'com.google.android.apps.wallpaper.pixel

com.ss.android.auto
3
1com.bootleggers.shishufied.clockfont.BudmoJiggler

com.android.localtransport
-
+com.android.systemui.brightness_slider.acun
-
+com.android.systemui.brightness_slider.bang
-
+com.android.systemui.brightness_slider.thin
#
!com.android.theme.font.samsungone
&
$com.google.android.wallpaper.effects

com.android.theme.font.nunito

com.android.carrierdefaultapp

com.dsi.ant.server

com.android.theme.font.oswald
"
 com.android.theme.font.coolstory
)
'com.android.theme.icon_pack.sam.android
/
-com.bootleggers.shishufied.clockfont.frankfrt
,
*com.android.theme.icon_pack.filled.android

com.android.proxyhandler
1
/com.android.theme.lockscreen_clock_font.linotte
!
com.android.theme.font.rosemary

com.android.theme.font.quando
9
7com.android.internal.display.cutout.emulation.waterfall

com.android.intentresolver
5
3com.android.theme.lockscreen_clock_font.harmonysans

com.android.nearby.halfsheet
;
9com.bootleggers.shishufied.clockfont.GautsMotelUpperRight
/
-com.android.theme.icon_pack.circular.systemui
1
/com.bootleggers.shishufied.clockfont.VTKSDURA3d

com.tenx.systemui.wifibar_a

com.tenx.systemui.wifibar_b

com.tenx.systemui.wifibar_c

com.tenx.systemui.wifibar_d

com.tenx.systemui.wifibar_e

com.tenx.systemui.wifibar_f

com.tenx.systemui.wifibar_g

com.tenx.systemui.wifibar_h

com.android.theme.font.roboto
 
com.customermobile.preload.vzw
&
$com.android.theme.font.arbutussource
#
!com.android.theme.font.rubikrubik

com.android.theme.font.surfer
1
/com.bootleggers.shishufied.clockfont.Brandayolq

com.google.android.feedback

com.topjohnwu.magisk
0
.com.google.android.printservice.recommendation
 
com.google.android.apps.photos

com.google.android.calendar
4
2com.android.theme.lockscreen_clock_font.sonysketch
)
'com.android.theme.icon_pack.kai.android

com.android.theme.font.ubuntu
!
com.android.managedprovisioning
$
"com.android.networkstack.tethering

com.android.soundpicker
7
5com.bootleggers.shishufied.clockfont.EditPointsFilled
'
%com.evolution.overlay.immnav.gestural

com.tencent.soter.soterserver
 
com.google.android.documentsui
3
1com.android.theme.lockscreen_clock_font.redressed
2
0com.bootleggers.shishufied.clockfont.Concentrate
/
-com.bootleggers.shishufied.clockfont.Ampad3D2

com.android.system.navbar.old
'
%com.google.android.systemui.gxoverlay
.
,com.bootleggers.shishufied.clockfont.Klyukin
(
&com.android.theme.font.robotocondensed
,
*com.google.android.apps.internal.betterbug
4
2com.android.theme.lockscreen_clock_font.cagliostro
*
(com.android.theme.icon_pack.kai.launcher
*
(com.bootleggers.shishufied.font.justsans

com.android.smspush

com.coolapk.market
1
/com.bootleggers.shishufied.clockfont.QuickSouth
"
 com.android.wallpaper.livepicker
0
.com.bootleggers.shishufied.clockfont.snowstorm
2
0com.android.theme.lockscreen_clock_font.rosemary
+
)com.google.android.flipendo.overlay.pixel
.
,com.bootleggers.shishufied.clockfont.riviera
2
0com.bootleggers.shishufied.clockfont.AlphaClouds
&
$com.android.theme.font.lgsmartgothic
 
com.android.theme.icon.hexagon
*
(com.android.cellbroadcastreceiver.module

com.android.theme.icon.ios
#
!com.android.imsserviceentitlement
6
4com.bootleggers.shishufied.clockfont.permanentmarker
4
2com.bootleggers.shishufied.clockfont.CFOneTwoTrees
*
(com.android.theme.icon_pack.sam.launcher
5
3com.bootleggers.shishufied.clockfont.threedisoblack
0
.com.bootleggers.shishufied.clockfont.Karamuruh
/
-com.bootleggers.shishufied.clockfont.headline
,
*com.google.android.apps.cbrsnetworkmonitor
A
?com.android.internal.display.cutout.emulation.avoidAppsInCutout
!
com.android.theme.icon.squircle
1
/com.bootleggers.shishufied.clockfont.EditPoints
$
"com.google.android.gms.supervision
1
/com.bootleggers.shishufied.clockfont.TH3MACHINE
,
*com.android.theme.icon_pack.victor.android
4
2com.bootleggers.shishufied.clockfont.PlantsLetters
#
!com.android.theme.font.evolvesans

com.android.bookmarkprovider
.
,com.google.android.overlay.pixelconfigcommon
!
com.googlecode.pythonforandroid

com.android.settings

com.qualcomm.qti.cne
#
!com.android.omadm.service.overlay
-
+com.bootleggers.shishufied.font.circularstd
3
1com.android.theme.lockscreen_clock_font.nokiapure
$
"com.google.android.apps.healthdata
-
+com.android.theme.icon_pack.filled.launcher
0
.com.bootleggers.shishufied.clockfont.mxwasgard
*
(com.google.android.settings.intelligence
(
&com.google.android.projection.gearhead

com.google.android.apps.turbo
4
2com.bootleggers.shishufied.clockfont.threedisobold
/
-com.android.theme.lockscreen_clock_font.cocon
/
-com.android.theme.lockscreen_clock_font.rubik
3
1com.android.theme.lockscreen_clock_font.comfortaa

com.android.cts.ctsshim
5
3com.google.android.apps.wearables.maestro.companion
9
7com.android.theme.lockscreen_clock_font.robotocondensed
2
0com.bootleggers.shishufied.clockfont.balticcoast
2
0com.bootleggers.shishufied.clockfont.AlmonteSnow
2
0com.bootleggers.shishufied.clockfont.balticstorm
0
.com.android.theme.lockscreen_clock_font.bariol
3
1com.android.theme.lockscreen_clock_font.comicsans
/
-com.android.theme.icon_pack.circular.launcher

org.lineageos.settings
0
.com.bootleggers.shishufied.clockfont.munsteria

com.android.wallpaper
!
com.android.theme.icon.cylinder
.
,com.bootleggers.shishufied.clockfont.REMPONK

com.android.vpndialogs
0
.com.android.theme.lockscreen_clock_font.exotwo
5
3com.bootleggers.shishufied.font.giganticfshezaedrus
$
"com.android.theme.font.oneplussans

com.google.android.odad
&
$com.custom.systemui.signalNothingDot
/
-com.bootleggers.shishufied.clockfont.roadrage

com.android.angle

com.android.music

com.android.phone

com.android.shell
0
.com.android.theme.icon_pack.filled.themepicker

com.android.sdksandbox

com.android.wallpaperbackup
%
#com.android.providers.blockednumber
'
%com.google.android.apps.work.clouddpc
&
$com.android.providers.userdictionary
$
"com.android.providers.media.module
1
/com.bootleggers.shishufied.clockfont.Fibography

com.android.emergency
"
 com.android.systemui.signalbar_k
"
 com.android.systemui.signalbar_l
"
 com.android.systemui.signalbar_m
:
8com.bootleggers.shishufied.clockfont.MonbijouxClownpiece

com.android.hotspot2.osulogin
)
'com.google.android.gms.location.history
/
-com.android.internal.systemui.navbar.gestural
2
0com.bootleggers.shishufied.clockfont.Romantiques

com.android.location.fused
0
.com.android.theme.icon_pack.victor.themepicker

com.android.systemui
4
2com.android.theme.lockscreen_clock_font.samsungone
"
 com.android.bluetoothmidiservice
 
com.qualcomm.qti.poweroffalarm
/
-com.bootleggers.shishufied.clockfont.Pinewood
0
.com.android.theme.lockscreen_clock_font.nunito
#
!com.android.theme.font.accuratist

com.qti.phone
0
.com.android.theme.lockscreen_clock_font.oswald
2
0com.bootleggers.shishufied.clockfont.LittleBunny
"
 com.android.permissioncontroller
>
<com.android.internal.display.cutout.emulation.notchbarkiller
0
.com.android.theme.lockscreen_clock_font.quando
"
 com.custom.systemui.signalbar_ab
"
 com.custom.systemui.signalbar_ac
"
 com.custom.systemui.signalbar_ad
"
 com.custom.systemui.signalbar_af
"
 com.custom.systemui.signalbar_ag
"
 com.custom.systemui.signalbar_ai
"
 com.custom.systemui.signalbar_aj
"
 com.custom.systemui.signalbar_ak
"
 com.custom.systemui.signalbar_al
"
 com.custom.systemui.signalbar_am
"
 com.custom.systemui.signalbar_an
"
 com.custom.systemui.signalbar_ao
"
 com.custom.systemui.signalbar_ap
"
 com.custom.systemui.signalbar_aq
"
 com.custom.systemui.signalbar_as
"
 com.custom.systemui.signalbar_au
/
-com.bootleggers.shishufied.clockfont.HotSweat
0
.com.android.theme.lockscreen_clock_font.surfer
+
)com.bootleggers.shishufied.clockfont.biko
1
/com.bootleggers.shishufied.clockfont.Kingthings
#
!com.android.system.navbar.oneplus
0
.com.bootleggers.shishufied.clockfont.SpaceGame
0
.com.android.theme.lockscreen_clock_font.ubuntu
-
+com.android.theme.icon_pack.sam.themepicker
.
,com.android.ondevicepersonalization.services

com.google.android.apps.gcs

com.android.bluetooth

com.qualcomm.timeservice
1
/com.bootleggers.shishufied.clockfont.Floorlight

com.android.theme.icon.cloudy
 
com.android.providers.contacts

com.netease.cloudmusic
$
"com.custom.systemui.wifiNothingDot
 
com.android.captiveportallogin
 
com.android.theme.font.linotte
 
org.pixelexperience.faceunlock
$
"com.android.theme.icon.roundedrect
5
3com.bootleggers.shishufied.clockfont.karmaticarcade
#
!com.android.theme.font.grandhotel
;
9com.android.internal.systemui.navbar.gestural_narrow_back

com.android.theme.icon.flower
.
,com.android.theme.icon_pack.rounded.settings
&
$com.google.android.inputmethod.latin
#
!com.google.android.storagemanager
.
,com.android.theme.icon_pack.circular.android
!
com.google.android.apps.restore
"
 com.android.theme.font.redressed

tornaco.apps.shortxAll 